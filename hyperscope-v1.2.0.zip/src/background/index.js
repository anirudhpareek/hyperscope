var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
(function() {
  "use strict";
  const API_URL = "https://api.hyperliquid.xyz/info";
  async function fetchInfo(body) {
    const response = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }
    return response.json();
  }
  async function getMetaAndAssetCtxs() {
    const data = await fetchInfo({
      type: "metaAndAssetCtxs"
    });
    const [meta, ctxs] = data;
    const universe = meta.universe.map((a) => a.name);
    const contexts = /* @__PURE__ */ new Map();
    universe.forEach((name, i) => {
      if (ctxs[i]) {
        contexts.set(name, ctxs[i]);
      }
    });
    return { universe, contexts };
  }
  async function getL2Book(coin, nLevels = 100) {
    return fetchInfo({
      type: "l2Book",
      coin,
      nSigFigs: 5,
      nLevels
    });
  }
  async function getCandles(coin, interval, startTime, endTime) {
    return fetchInfo({
      type: "candleSnapshot",
      req: {
        coin,
        interval,
        startTime,
        ...endTime
      }
    });
  }
  async function getFundingHistory(coin, startTime, endTime) {
    return fetchInfo({
      type: "fundingHistory",
      coin,
      startTime,
      ...endTime
    });
  }
  const WS_URL = "wss://api.hyperliquid.xyz/ws";
  const RECONNECT_DELAY = 3e3;
  const HEARTBEAT_INTERVAL = 3e4;
  class WebSocketManager {
    constructor() {
      __publicField(this, "ws", null);
      __publicField(this, "subscriptions", /* @__PURE__ */ new Map());
      __publicField(this, "handlers", /* @__PURE__ */ new Map());
      __publicField(this, "reconnecting", false);
      __publicField(this, "heartbeatTimer", null);
      this.connect();
    }
    connect() {
      var _a;
      if (((_a = this.ws) == null ? void 0 : _a.readyState) === WebSocket.OPEN) return;
      this.ws = new WebSocket(WS_URL);
      this.ws.onopen = () => {
        console.log("[WS] Connected");
        this.reconnecting = false;
        this.resubscribeAll();
        this.startHeartbeat();
      };
      this.ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          this.handleMessage(msg);
        } catch (e) {
          console.error("[WS] Parse error:", e);
        }
      };
      this.ws.onclose = () => {
        console.log("[WS] Disconnected");
        this.stopHeartbeat();
        this.scheduleReconnect();
      };
      this.ws.onerror = (error) => {
        console.error("[WS] Error:", error);
      };
    }
    handleMessage(msg) {
      if (!msg || typeof msg !== "object") return;
      const message = msg;
      if (!message.channel || message.channel === "subscriptionResponse") return;
      const channel = message.channel;
      const handlers = this.handlers.get(channel);
      if (handlers) {
        handlers.forEach((handler) => {
          handler({ channel, data: message.data });
        });
      }
    }
    scheduleReconnect() {
      if (this.reconnecting) return;
      this.reconnecting = true;
      setTimeout(() => this.connect(), RECONNECT_DELAY);
    }
    resubscribeAll() {
      this.subscriptions.forEach((sub) => {
        this.sendSubscribe(sub);
      });
    }
    startHeartbeat() {
      this.heartbeatTimer = setInterval(() => {
        var _a;
        if (((_a = this.ws) == null ? void 0 : _a.readyState) === WebSocket.OPEN) {
          this.ws.send(JSON.stringify({ method: "ping" }));
        }
      }, HEARTBEAT_INTERVAL);
    }
    stopHeartbeat() {
      if (this.heartbeatTimer) {
        clearInterval(this.heartbeatTimer);
        this.heartbeatTimer = null;
      }
    }
    sendSubscribe(subscription) {
      var _a;
      if (((_a = this.ws) == null ? void 0 : _a.readyState) !== WebSocket.OPEN) return;
      this.ws.send(
        JSON.stringify({
          method: "subscribe",
          subscription
        })
      );
    }
    sendUnsubscribe(subscription) {
      var _a;
      if (((_a = this.ws) == null ? void 0 : _a.readyState) !== WebSocket.OPEN) return;
      this.ws.send(
        JSON.stringify({
          method: "unsubscribe",
          subscription
        })
      );
    }
    getSubKey(sub) {
      return sub.coin ? `${sub.type}:${sub.coin}` : sub.type;
    }
    subscribe(subscription, handler) {
      const key = this.getSubKey(subscription);
      if (!this.subscriptions.has(key)) {
        this.subscriptions.set(key, subscription);
        this.sendSubscribe(subscription);
      }
      if (!this.handlers.has(subscription.type)) {
        this.handlers.set(subscription.type, /* @__PURE__ */ new Set());
      }
      this.handlers.get(subscription.type).add(handler);
      return () => {
        const handlers = this.handlers.get(subscription.type);
        if (handlers) {
          handlers.delete(handler);
          if (handlers.size === 0) {
            this.handlers.delete(subscription.type);
            this.subscriptions.delete(key);
            this.sendUnsubscribe(subscription);
          }
        }
      };
    }
    subscribeToBook(coin, handler) {
      return this.subscribe({ type: "l2Book", coin }, (msg) => {
        if (msg.channel === "l2Book") {
          handler(msg.data);
        }
      });
    }
    subscribeToTrades(coin, handler) {
      return this.subscribe({ type: "trades", coin }, (msg) => {
        if (msg.channel === "trades") {
          handler(msg.data);
        }
      });
    }
    subscribeToAssetCtx(coin, handler) {
      return this.subscribe({ type: "activeAssetCtx", coin }, (msg) => {
        if (msg.channel === "activeAssetCtx") {
          handler(msg.data);
        }
      });
    }
    subscribeToAllMids(handler) {
      return this.subscribe({ type: "allMids" }, (msg) => {
        if (msg.channel === "allMids") {
          const mids = msg.data.mids;
          handler(mids);
        }
      });
    }
    disconnect() {
      this.stopHeartbeat();
      if (this.ws) {
        this.ws.close();
        this.ws = null;
      }
      this.subscriptions.clear();
      this.handlers.clear();
    }
  }
  const wsManager = new WebSocketManager();
  const AVG_LEVERAGE = 10;
  const RISK_FRACTION = 0.3;
  function getFundingRegime(annualizedRate) {
    if (annualizedRate > 0.5) return "extreme_positive";
    if (annualizedRate > 0.2) return "positive";
    if (annualizedRate < -0.5) return "extreme_negative";
    if (annualizedRate < -0.2) return "negative";
    return "neutral";
  }
  function estimateLiquidations(openInterest, price, isLongs) {
    const oiNotional = openInterest * price;
    const positionFraction = 0.5;
    const marginAtRisk = oiNotional * positionFraction * (1 / AVG_LEVERAGE) * RISK_FRACTION;
    return marginAtRisk;
  }
  function getUpsideFundingImpact(regime) {
    if (regime === "extreme_positive") return "positive";
    if (regime === "extreme_negative") return "negative";
    return "neutral";
  }
  function getDownsideFundingImpact(regime) {
    if (regime === "extreme_negative") return "positive";
    if (regime === "extreme_positive") return "negative";
    return "neutral";
  }
  function getUpsideOiImplication(fundingRate) {
    if (fundingRate > 1e-4) return "Short squeeze → OI likely drops";
    if (fundingRate < -1e-4) return "Counter-trend rally → OI may rise";
    return "Breakout → OI direction unclear";
  }
  function getDownsideOiImplication(fundingRate) {
    if (fundingRate < -1e-4) return "Long squeeze → OI likely drops";
    if (fundingRate > 1e-4) return "Counter-trend drop → OI may rise";
    return "Breakdown → OI direction unclear";
  }
  function getBeneficiary(fundingRate, isUpside) {
    const threshold = 1e-4;
    if (isUpside) {
      if (fundingRate > threshold) return "longs";
      if (fundingRate < -threshold) return "shorts";
    } else {
      if (fundingRate < -threshold) return "shorts";
      if (fundingRate > threshold) return "longs";
    }
    return "neutral";
  }
  function findVacuumZones(orderbook, price) {
    const zones = [];
    const avgSize = orderbook.bids.reduce((sum, b) => sum + b.size, 0) / orderbook.bids.length;
    for (const bid of orderbook.bids) {
      if (bid.size < avgSize * 0.3) {
        const pctBelow = (price - bid.price) / price;
        if (pctBelow > 0.01 && pctBelow < 0.05) {
          zones.push(bid.price);
        }
      }
    }
    return zones.slice(0, 3);
  }
  function calculatePressureMap(market, orderbook) {
    const { price, openInterest, fundingRate, fundingAnnualized } = market;
    const regime = getFundingRegime(fundingAnnualized);
    const upside = {
      liqEstimate: estimateLiquidations(openInterest, price * 1.05),
      fundingImpact: getUpsideFundingImpact(regime),
      oiImplication: getUpsideOiImplication(fundingRate),
      structuralBeneficiary: getBeneficiary(fundingRate, true),
      vacuumZones: []
      // Not applicable for upside
    };
    const downside = {
      liqEstimate: estimateLiquidations(openInterest, price * 0.95),
      fundingImpact: getDownsideFundingImpact(regime),
      oiImplication: getDownsideOiImplication(fundingRate),
      structuralBeneficiary: getBeneficiary(fundingRate, false),
      trapRisk: fundingRate > 5e-4 ? "longs" : fundingRate < -5e-4 ? "shorts" : "neutral"
    };
    const vacuumZones = findVacuumZones(orderbook, price);
    return {
      upside: { ...upside, vacuumZones },
      downside
    };
  }
  function analyzeDepth(levels, currentPrice, isAbove) {
    if (levels.length === 0) {
      return { thinZoneDistance: null, cumulativeDepth: 0, avgLevelSize: 0 };
    }
    const avgSize = levels.reduce((sum, l) => sum + l.size, 0) / levels.length;
    let cumulativeDepth = 0;
    let thinZoneDistance = null;
    for (const level of levels) {
      const distance = Math.abs(level.price - currentPrice) / currentPrice;
      if (distance > 0.05) break;
      cumulativeDepth += level.size;
      if (level.size < avgSize * 0.3 && thinZoneDistance === null && distance > 5e-3) {
        thinZoneDistance = distance;
      }
    }
    return {
      thinZoneDistance,
      cumulativeDepth,
      avgLevelSize: avgSize
    };
  }
  function calculateLiquidationGravity(orderbook, currentPrice) {
    const askAnalysis = analyzeDepth(orderbook.asks, currentPrice);
    const bidAnalysis = analyzeDepth(orderbook.bids, currentPrice);
    const totalDepth = askAnalysis.cumulativeDepth + bidAnalysis.cumulativeDepth;
    const densityAbove = totalDepth > 0 ? askAnalysis.cumulativeDepth / totalDepth : 0.5;
    const densityBelow = totalDepth > 0 ? bidAnalysis.cumulativeDepth / totalDepth : 0.5;
    const imbalance = densityAbove - densityBelow;
    let score = "BALANCED";
    if (askAnalysis.thinZoneDistance !== null && askAnalysis.thinZoneDistance < 0.03 && imbalance < -0.2) {
      score = "HIGH_ABOVE";
    } else if (bidAnalysis.thinZoneDistance !== null && bidAnalysis.thinZoneDistance < 0.03 && imbalance > 0.2) {
      score = "HIGH_BELOW";
    }
    return {
      score,
      nearestAbove: askAnalysis.thinZoneDistance,
      nearestBelow: bidAnalysis.thinZoneDistance,
      densityAbove,
      densityBelow
    };
  }
  function mean(values) {
    if (values.length === 0) return 0;
    return values.reduce((a, b) => a + b, 0) / values.length;
  }
  function stdDev(values) {
    if (values.length < 2) return 0;
    const avg = mean(values);
    const squareDiffs = values.map((v) => Math.pow(v - avg, 2));
    return Math.sqrt(mean(squareDiffs));
  }
  function percentileRank(value, values) {
    if (values.length === 0) return 0.5;
    const sorted = [...values].sort((a, b) => a - b);
    const index = sorted.findIndex((v) => v >= value);
    if (index === -1) return 1;
    return index / sorted.length;
  }
  function bollingerWidth(closes, period = 20) {
    if (closes.length < period) return 0;
    const recent = closes.slice(-period);
    const sma = mean(recent);
    const std = stdDev(recent);
    return 2 * std / sma;
  }
  function historicalBollingerWidths(closes, period = 20, lookback = 100) {
    const widths = [];
    for (let i = period; i <= closes.length && widths.length < lookback; i++) {
      const slice = closes.slice(i - period, i);
      const sma = mean(slice);
      const std = stdDev(slice);
      if (sma > 0) {
        widths.push(2 * std / sma);
      }
    }
    return widths;
  }
  function calculateVolatilityState(candles) {
    if (candles.length < 20) {
      return {
        atr14: 0,
        range24h: 0,
        bbWidth: 0,
        bbWidthPercentile: 0.5,
        historicalVolatility: 0
      };
    }
    const closes = candles.map((c) => parseFloat(c.c));
    const highs = candles.map((c) => parseFloat(c.h));
    const lows = candles.map((c) => parseFloat(c.l));
    const trueRanges = [];
    for (let i = 1; i < candles.length; i++) {
      const h = highs[i];
      const l = lows[i];
      const prevC = closes[i - 1];
      const tr = Math.max(h - l, Math.abs(h - prevC), Math.abs(l - prevC));
      trueRanges.push(tr);
    }
    const atr14 = mean(trueRanges.slice(-14));
    const last96 = candles.slice(-96);
    const high24h = Math.max(...last96.map((c) => parseFloat(c.h)));
    const low24h = Math.min(...last96.map((c) => parseFloat(c.l)));
    const mid24h = (high24h + low24h) / 2;
    const range24h = mid24h > 0 ? (high24h - low24h) / mid24h : 0;
    const bbWidth = bollingerWidth(closes, 20);
    const historicalWidths = historicalBollingerWidths(closes, 20, 100);
    const bbWidthPercentile = percentileRank(bbWidth, historicalWidths);
    const returns = [];
    for (let i = 1; i < closes.length; i++) {
      if (closes[i - 1] > 0) {
        returns.push(Math.log(closes[i] / closes[i - 1]));
      }
    }
    const dailyVol = stdDev(returns);
    const historicalVolatility = dailyVol * Math.sqrt(365 * 96);
    return {
      atr14,
      range24h,
      bbWidth,
      bbWidthPercentile,
      historicalVolatility
    };
  }
  function calculateVolumeState(recentVolume, avgVolume) {
    const ratio = avgVolume > 0 ? recentVolume / avgVolume : 1;
    return {
      recent15m: recentVolume,
      avg15m: avgVolume,
      ratio,
      declining: ratio < 0.7
    };
  }
  function detectCompression(input) {
    const { candles, currentOI, priorOI, fundingRate, recentVolume, avgVolume } = input;
    const volatility = calculateVolatilityState(candles);
    const rangeNarrowing = volatility.bbWidthPercentile < 0.2;
    const oiChange = priorOI > 0 ? (currentOI - priorOI) / priorOI : 0;
    const oiRising = oiChange > 0.05;
    const fundingAnnualized = Math.abs(fundingRate * 24 * 365);
    const fundingExtreme = fundingAnnualized > 0.5 || fundingAnnualized < 0.05;
    const volumeRatio = avgVolume > 0 ? recentVolume / avgVolume : 1;
    const volumeDeclining = volumeRatio < 0.7;
    const signals = {
      rangeNarrowing,
      oiRising,
      fundingExtreme,
      volumeDeclining
    };
    const score = Object.values(signals).filter(Boolean).length;
    return {
      isCompressed: score >= 3,
      signals,
      score
    };
  }
  function calculateTrapRisk(input) {
    const {
      currentOI,
      currentFunding,
      currentPrice,
      priorSnapshot,
      fundingHistory
    } = input;
    const oiDelta = priorSnapshot.openInterest > 0 ? (currentOI - priorSnapshot.openInterest) / priorSnapshot.openInterest : 0;
    const oiRisingAggressively = oiDelta > 0.1;
    const fundingMean = mean(fundingHistory);
    const fundingStd = stdDev(fundingHistory);
    const fundingDeviation = fundingStd > 0 ? (currentFunding - fundingMean) / fundingStd : 0;
    const fundingExtreme = Math.abs(fundingDeviation) > 2;
    const priceMove = priorSnapshot.price > 0 ? (currentPrice - priorSnapshot.price) / priorSnapshot.price : 0;
    const priceMoveSmall = Math.abs(priceMove) < 0.02;
    const elevated = oiRisingAggressively && fundingExtreme && priceMoveSmall;
    let direction = null;
    if (elevated) {
      direction = currentFunding > 0 ? "long" : "short";
    }
    return {
      elevated,
      oiDelta: oiDelta * 100,
      // As percentage
      fundingDeviation,
      priceMovement: priceMove * 100,
      // As percentage
      direction
    };
  }
  function createSnapshot(openInterest, fundingRate, price) {
    return {
      timestamp: Date.now(),
      openInterest,
      fundingRate,
      price
    };
  }
  class CVDCalculator {
    constructor() {
      __publicField(this, "trades", []);
      __publicField(this, "priceHistory", []);
      // Time windows in ms
      __publicField(this, "WINDOW_5M", 5 * 60 * 1e3);
      __publicField(this, "WINDOW_15M", 15 * 60 * 1e3);
      __publicField(this, "WINDOW_1H", 60 * 60 * 1e3);
      __publicField(this, "MAX_HISTORY", 2 * 60 * 60 * 1e3);
    }
    // Keep 2 hours
    addTrade(trade) {
      this.trades.push(trade);
      this.priceHistory.push({ timestamp: trade.timestamp, price: trade.price });
      this.cleanup();
    }
    cleanup() {
      const cutoff = Date.now() - this.MAX_HISTORY;
      this.trades = this.trades.filter((t) => t.timestamp > cutoff);
      this.priceHistory = this.priceHistory.filter((p) => p.timestamp > cutoff);
    }
    calculateDelta(windowMs) {
      const cutoff = Date.now() - windowMs;
      const windowTrades = this.trades.filter((t) => t.timestamp > cutoff);
      return windowTrades.reduce((delta, trade) => {
        const volume = trade.size;
        return delta + (trade.side === "buy" ? volume : -volume);
      }, 0);
    }
    calculateCumulativeDelta() {
      return this.trades.reduce((delta, trade) => {
        const volume = trade.size;
        return delta + (trade.side === "buy" ? volume : -volume);
      }, 0);
    }
    getMomentum(delta5m, delta15m) {
      const ratio = delta15m !== 0 ? delta5m / Math.abs(delta15m) : 0;
      if (delta5m > 0 && ratio > 0.5) return "strong_buy";
      if (delta5m > 0) return "buy";
      if (delta5m < 0 && ratio < -0.5) return "strong_sell";
      if (delta5m < 0) return "sell";
      return "neutral";
    }
    detectDivergence(delta1h) {
      if (this.priceHistory.length < 10) return null;
      const cutoff1h = Date.now() - this.WINDOW_1H;
      const hourPrices = this.priceHistory.filter((p) => p.timestamp > cutoff1h);
      if (hourPrices.length < 2) return null;
      const priceStart = hourPrices[0].price;
      const priceEnd = hourPrices[hourPrices.length - 1].price;
      const priceChange = (priceEnd - priceStart) / priceStart;
      if (priceChange < -5e-3 && delta1h > 0) {
        return "bullish";
      }
      if (priceChange > 5e-3 && delta1h < 0) {
        return "bearish";
      }
      return null;
    }
    getState() {
      const cumulative = this.calculateCumulativeDelta();
      const delta5m = this.calculateDelta(this.WINDOW_5M);
      const delta15m = this.calculateDelta(this.WINDOW_15M);
      const delta1h = this.calculateDelta(this.WINDOW_1H);
      return {
        cumulative,
        delta5m,
        delta15m,
        delta1h,
        momentum: this.getMomentum(delta5m, delta15m),
        divergence: this.detectDivergence(delta1h),
        lastUpdate: Date.now()
      };
    }
    reset() {
      this.trades = [];
      this.priceHistory = [];
    }
  }
  const cvdCalculator = new CVDCalculator();
  class TapeTracker {
    constructor() {
      __publicField(this, "trades", []);
      __publicField(this, "MAX_TRADES", 100);
      __publicField(this, "WHALE_THRESHOLD_USD", 5e4);
      // $50k = whale trade
      __publicField(this, "WINDOW_5M", 5 * 60 * 1e3);
    }
    addTrade(trade, markPrice) {
      const notional = trade.size * markPrice;
      const isWhale = notional >= this.WHALE_THRESHOLD_USD;
      const entry = {
        timestamp: trade.timestamp,
        price: trade.price,
        size: trade.size,
        side: trade.side,
        notional,
        isWhale
      };
      this.trades.unshift(entry);
      if (this.trades.length > this.MAX_TRADES) {
        this.trades = this.trades.slice(0, this.MAX_TRADES);
      }
      return isWhale ? entry : null;
    }
    getRecentWhales() {
      const cutoff = Date.now() - this.WINDOW_5M;
      return this.trades.filter((t) => t.isWhale && t.timestamp > cutoff);
    }
    calculateIntensity(side) {
      const cutoff = Date.now() - this.WINDOW_5M;
      const recentTrades = this.trades.filter((t) => t.timestamp > cutoff);
      if (recentTrades.length === 0) return 50;
      const sideVolume = recentTrades.filter((t) => t.side === side).reduce((sum, t) => sum + t.notional, 0);
      const totalVolume = recentTrades.reduce((sum, t) => sum + t.notional, 0);
      if (totalVolume === 0) return 50;
      return Math.round(sideVolume / totalVolume * 100);
    }
    getState() {
      const recentWhales = this.getRecentWhales();
      const whaleBuyVolume = recentWhales.filter((t) => t.side === "buy").reduce((sum, t) => sum + t.notional, 0);
      const whaleSellVolume = recentWhales.filter((t) => t.side === "sell").reduce((sum, t) => sum + t.notional, 0);
      const lastWhale = this.trades.find((t) => t.isWhale) || null;
      return {
        recentTrades: this.trades.slice(0, 20),
        // Last 20 for display
        whaleCount5m: recentWhales.length,
        whaleBuyVolume,
        whaleSellVolume,
        buyIntensity: this.calculateIntensity("buy"),
        sellIntensity: this.calculateIntensity("sell"),
        lastWhale
      };
    }
    reset() {
      this.trades = [];
    }
  }
  const tapeTracker = new TapeTracker();
  class OIDivergenceDetector {
    constructor() {
      __publicField(this, "snapshots", []);
      __publicField(this, "WINDOW_1H", 60 * 60 * 1e3);
      __publicField(this, "WINDOW_4H", 4 * 60 * 60 * 1e3);
      __publicField(this, "MAX_HISTORY", 8 * 60 * 60 * 1e3);
    }
    // 8 hours
    addSnapshot(oi, price) {
      this.snapshots.push({
        timestamp: Date.now(),
        openInterest: oi,
        price
      });
      this.cleanup();
    }
    cleanup() {
      const cutoff = Date.now() - this.MAX_HISTORY;
      this.snapshots = this.snapshots.filter((s) => s.timestamp > cutoff);
    }
    getPattern(priceChange, oiChange) {
      const priceUp = priceChange > 5e-3;
      const priceDown = priceChange < -5e-3;
      const oiUp = oiChange > 0.02;
      const oiDown = oiChange < -0.02;
      if (priceUp && oiDown) return "short_covering";
      if (priceDown && oiUp) return "new_shorts";
      if (priceUp && oiUp) return "new_longs";
      if (priceDown && oiDown) return "long_liquidation";
      return null;
    }
    getStrength(priceChange, oiChange) {
      const magnitude = Math.abs(priceChange) + Math.abs(oiChange);
      if (magnitude > 0.15) return "strong";
      if (magnitude > 0.08) return "moderate";
      return "weak";
    }
    calculateScore(priceChange, oiChange, pattern) {
      if (!pattern) return 0;
      const magnitude = Math.min(Math.abs(priceChange) + Math.abs(oiChange), 0.3);
      const normalizedMagnitude = magnitude / 0.3 * 100;
      switch (pattern) {
        case "new_longs":
          return Math.round(normalizedMagnitude);
        case "short_covering":
          return Math.round(normalizedMagnitude * 0.5);
        case "new_shorts":
          return Math.round(-normalizedMagnitude);
        case "long_liquidation":
          return Math.round(-normalizedMagnitude * 0.7);
        default:
          return 0;
      }
    }
    getState() {
      if (this.snapshots.length < 2) {
        return {
          score: 0,
          pattern: null,
          strength: "weak",
          priceChange: 0,
          oiChange: 0
        };
      }
      const cutoff1h = Date.now() - this.WINDOW_1H;
      const oldSnapshots = this.snapshots.filter((s) => s.timestamp < cutoff1h);
      if (oldSnapshots.length === 0) {
        const oldest = this.snapshots[0];
        const newest = this.snapshots[this.snapshots.length - 1];
        const priceChange2 = (newest.price - oldest.price) / oldest.price;
        const oiChange2 = (newest.openInterest - oldest.openInterest) / oldest.openInterest;
        const pattern2 = this.getPattern(priceChange2, oiChange2);
        return {
          score: this.calculateScore(priceChange2, oiChange2, pattern2),
          pattern: pattern2,
          strength: this.getStrength(priceChange2, oiChange2),
          priceChange: priceChange2 * 100,
          oiChange: oiChange2 * 100
        };
      }
      const baseline = oldSnapshots[oldSnapshots.length - 1];
      const current = this.snapshots[this.snapshots.length - 1];
      const priceChange = (current.price - baseline.price) / baseline.price;
      const oiChange = (current.openInterest - baseline.openInterest) / baseline.openInterest;
      const pattern = this.getPattern(priceChange, oiChange);
      return {
        score: this.calculateScore(priceChange, oiChange, pattern),
        pattern,
        strength: this.getStrength(priceChange, oiChange),
        priceChange: priceChange * 100,
        oiChange: oiChange * 100
      };
    }
    reset() {
      this.snapshots = [];
    }
  }
  const oiDivergenceDetector = new OIDivergenceDetector();
  const POLL_INTERVAL = 5e3;
  const CANDLE_INTERVAL = 6e4;
  const HISTORY_SNAPSHOT_INTERVAL = 36e5;
  class StateManager {
    constructor() {
      __publicField(this, "currentCoin", null);
      __publicField(this, "state", null);
      __publicField(this, "listeners", /* @__PURE__ */ new Set());
      // Raw data cache
      __publicField(this, "assetContext", null);
      __publicField(this, "orderbook", null);
      __publicField(this, "candles", []);
      __publicField(this, "fundingHistory", []);
      // Historical snapshots for trap detection
      __publicField(this, "snapshots", []);
      // Timers
      __publicField(this, "pollTimer", null);
      __publicField(this, "candleTimer", null);
      __publicField(this, "snapshotTimer", null);
      // WS unsubscribe functions
      __publicField(this, "wsUnsubscribers", []);
    }
    subscribe(listener) {
      this.listeners.add(listener);
      if (this.state) {
        listener(this.state);
      }
      return () => this.listeners.delete(listener);
    }
    notify() {
      console.log("[State] notify called, listeners:", this.listeners.size, "state:", this.state ? "set" : "null");
      if (this.state) {
        this.listeners.forEach((l) => l(this.state));
      }
    }
    async setCoin(coin) {
      console.log("[State] setCoin called:", coin, "current:", this.currentCoin);
      if (this.currentCoin === coin) return;
      this.cleanup();
      this.currentCoin = coin;
      await this.fetchInitialData();
      this.setupWebSocket();
      this.startPolling();
      this.takeSnapshot();
      console.log("[State] setCoin complete, state:", this.state ? "set" : "null");
    }
    async fetchInitialData() {
      var _a;
      if (!this.currentCoin) return;
      console.log("[State] Fetching initial data for:", this.currentCoin);
      try {
        const [metaData, book, candles, funding] = await Promise.all([
          getMetaAndAssetCtxs(),
          getL2Book(this.currentCoin),
          getCandles(
            this.currentCoin,
            "15m",
            Date.now() - 24 * 60 * 60 * 1e3
            // Last 24h
          ),
          getFundingHistory(
            this.currentCoin,
            Date.now() - 7 * 24 * 60 * 60 * 1e3
            // Last 7 days
          )
        ]);
        console.log("[State] Got metaData, contexts size:", metaData.contexts.size);
        console.log("[State] Got book levels:", (_a = book == null ? void 0 : book.levels) == null ? void 0 : _a.length);
        console.log("[State] Got candles:", candles == null ? void 0 : candles.length);
        console.log("[State] Got funding:", funding == null ? void 0 : funding.length);
        this.assetContext = metaData.contexts.get(this.currentCoin) || null;
        console.log("[State] Asset context for", this.currentCoin, ":", this.assetContext ? "found" : "not found");
        this.orderbook = book;
        this.candles = candles;
        this.fundingHistory = funding;
        this.recalculate();
      } catch (error) {
        console.error("[State] Initial fetch error:", error);
      }
    }
    setupWebSocket() {
      if (!this.currentCoin) return;
      const unsubBook = wsManager.subscribeToBook(this.currentCoin, (data) => {
        this.orderbook = data;
        this.recalculate();
      });
      const unsubCtx = wsManager.subscribeToAssetCtx(this.currentCoin, (data) => {
        if (data.coin === this.currentCoin) {
          this.assetContext = data.ctx;
          const oi = parseFloat(data.ctx.openInterest);
          const price = parseFloat(data.ctx.markPx);
          oiDivergenceDetector.addSnapshot(oi, price);
          this.recalculate();
        }
      });
      const unsubTrades = wsManager.subscribeToTrades(this.currentCoin, (trades) => {
        const markPrice = this.assetContext ? parseFloat(this.assetContext.markPx) : 0;
        for (const trade of trades) {
          const side = trade.side === "B" ? "buy" : "sell";
          const size = parseFloat(trade.sz);
          const price = parseFloat(trade.px);
          cvdCalculator.addTrade({
            timestamp: trade.time,
            size,
            side,
            price
          });
          tapeTracker.addTrade(
            { timestamp: trade.time, price, size, side },
            markPrice || price
          );
        }
        this.recalculate();
      });
      this.wsUnsubscribers = [unsubBook, unsubCtx, unsubTrades];
    }
    startPolling() {
      this.pollTimer = setInterval(async () => {
        if (!this.currentCoin) return;
        try {
          const data = await getMetaAndAssetCtxs();
          const ctx = data.contexts.get(this.currentCoin);
          if (ctx) {
            this.assetContext = ctx;
            this.recalculate();
          }
        } catch (e) {
          console.error("[State] Poll error:", e);
        }
      }, POLL_INTERVAL);
      this.candleTimer = setInterval(async () => {
        if (!this.currentCoin) return;
        try {
          const candles = await getCandles(
            this.currentCoin,
            "15m",
            Date.now() - 24 * 60 * 60 * 1e3
          );
          this.candles = candles;
          this.recalculate();
        } catch (e) {
          console.error("[State] Candle poll error:", e);
        }
      }, CANDLE_INTERVAL);
      this.snapshotTimer = setInterval(() => {
        this.takeSnapshot();
      }, HISTORY_SNAPSHOT_INTERVAL);
    }
    takeSnapshot() {
      if (!this.assetContext) return;
      const snapshot = createSnapshot(
        parseFloat(this.assetContext.openInterest),
        parseFloat(this.assetContext.funding),
        parseFloat(this.assetContext.markPx)
      );
      this.snapshots.push(snapshot);
      const cutoff = Date.now() - 24 * 60 * 60 * 1e3;
      this.snapshots = this.snapshots.filter((s) => s.timestamp > cutoff);
    }
    getOrderbookState() {
      var _a, _b;
      if (!this.orderbook || !this.assetContext) {
        return {
          coin: this.currentCoin || "",
          bids: [],
          asks: [],
          bidDepthPct: [0, 0, 0, 0, 0],
          askDepthPct: [0, 0, 0, 0, 0],
          imbalance: 0,
          spreadPct: 0,
          lastUpdate: Date.now()
        };
      }
      const price = parseFloat(this.assetContext.markPx);
      const [rawBids, rawAsks] = this.orderbook.levels;
      const bids = rawBids.map((l) => ({
        price: parseFloat(l.px),
        size: parseFloat(l.sz),
        count: l.n
      }));
      const asks = rawAsks.map((l) => ({
        price: parseFloat(l.px),
        size: parseFloat(l.sz),
        count: l.n
      }));
      const pctLevels = [0.01, 0.02, 0.03, 0.04, 0.05];
      const bidDepthPct = pctLevels.map((pct) => {
        const threshold = price * (1 - pct);
        return bids.filter((b) => b.price >= threshold).reduce((sum, b) => sum + b.size, 0);
      });
      const askDepthPct = pctLevels.map((pct) => {
        const threshold = price * (1 + pct);
        return asks.filter((a) => a.price <= threshold).reduce((sum, a) => sum + a.size, 0);
      });
      const bidDepth2 = bidDepthPct[1];
      const askDepth2 = askDepthPct[1];
      const total = bidDepth2 + askDepth2;
      const imbalance = total > 0 ? (bidDepth2 - askDepth2) / total : 0;
      const bestBid = ((_a = bids[0]) == null ? void 0 : _a.price) || 0;
      const bestAsk = ((_b = asks[0]) == null ? void 0 : _b.price) || 0;
      const spreadPct = bestBid > 0 ? (bestAsk - bestBid) / bestBid : 0;
      return {
        coin: this.currentCoin || "",
        bids,
        asks,
        bidDepthPct,
        askDepthPct,
        imbalance,
        spreadPct,
        lastUpdate: Date.now()
      };
    }
    recalculate() {
      if (!this.currentCoin || !this.assetContext) return;
      const ctx = this.assetContext;
      const price = parseFloat(ctx.markPx);
      const fundingRate = parseFloat(ctx.funding);
      const market = {
        coin: this.currentCoin,
        price,
        markPrice: parseFloat(ctx.markPx),
        oraclePrice: parseFloat(ctx.oraclePx),
        openInterest: parseFloat(ctx.openInterest),
        fundingRate,
        fundingAnnualized: fundingRate * 24 * 365,
        premium: parseFloat(ctx.premium),
        dayVolume: parseFloat(ctx.dayNtlVlm),
        lastUpdate: Date.now()
      };
      const orderbook = this.getOrderbookState();
      const volatility = this.candles.length > 0 ? calculateVolatilityState(this.candles) : { atr14: 0, range24h: 0, bbWidth: 0, bbWidthPercentile: 0.5, historicalVolatility: 0 };
      const recentCandles = this.candles.slice(-4);
      const priorCandles = this.candles.slice(-20, -4);
      const recentVolume = recentCandles.reduce((sum, c) => sum + parseFloat(c.v), 0);
      const avgVolume = priorCandles.length > 0 ? priorCandles.reduce((sum, c) => sum + parseFloat(c.v), 0) / priorCandles.length * 4 : recentVolume;
      const volume = calculateVolumeState(recentVolume, avgVolume);
      const pressure = calculatePressureMap(market, orderbook);
      const gravity = calculateLiquidationGravity(orderbook, price);
      const priorOI = this.snapshots.length > 0 ? this.snapshots[0].openInterest : market.openInterest;
      const compression = detectCompression({
        candles: this.candles,
        currentOI: market.openInterest,
        priorOI,
        fundingRate,
        recentVolume,
        avgVolume
      });
      const priorSnapshot = this.snapshots.length > 0 ? this.snapshots[0] : createSnapshot(market.openInterest, fundingRate, price);
      const fundingRates = this.fundingHistory.map((f) => parseFloat(f.fundingRate));
      const trap = calculateTrapRisk({
        currentOI: market.openInterest,
        currentFunding: fundingRate,
        currentPrice: price,
        priorSnapshot,
        fundingHistory: fundingRates.length > 0 ? fundingRates : [fundingRate]
      });
      const cvd = cvdCalculator.getState();
      const tape = tapeTracker.getState();
      const oiDivergence = oiDivergenceDetector.getState();
      this.state = {
        coin: this.currentCoin,
        market,
        orderbook,
        volatility,
        volume,
        pressure,
        gravity,
        compression,
        trap,
        cvd,
        tape,
        oiDivergence,
        lastUpdate: Date.now()
      };
      this.notify();
    }
    cleanup() {
      if (this.pollTimer) clearInterval(this.pollTimer);
      if (this.candleTimer) clearInterval(this.candleTimer);
      if (this.snapshotTimer) clearInterval(this.snapshotTimer);
      this.wsUnsubscribers.forEach((unsub) => unsub());
      this.wsUnsubscribers = [];
      cvdCalculator.reset();
      tapeTracker.reset();
      oiDivergenceDetector.reset();
      this.assetContext = null;
      this.orderbook = null;
      this.candles = [];
      this.snapshots = [];
      this.state = null;
      this.currentCoin = null;
    }
    getState() {
      return this.state;
    }
    getCurrentCoin() {
      return this.currentCoin;
    }
  }
  const stateManager = new StateManager();
  const connectedPorts = /* @__PURE__ */ new Map();
  chrome.action.onClicked.addListener((tab) => {
    if (tab.id) {
      chrome.sidePanel.open({ tabId: tab.id });
    }
  });
  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    var _a;
    if (changeInfo.status === "complete" && ((_a = tab.url) == null ? void 0 : _a.includes("app.hyperliquid.xyz"))) {
      chrome.sidePanel.setOptions({
        tabId,
        path: "sidepanel.html",
        enabled: true
      });
    }
  });
  chrome.runtime.onConnect.addListener((port) => {
    const portId = `${port.name}-${Date.now()}`;
    console.log(`[BG] Port connected: ${port.name}`);
    connectedPorts.set(portId, port);
    const unsubscribe = stateManager.subscribe((state) => {
      try {
        port.postMessage({ type: "STATE_UPDATE", payload: state });
      } catch (e) {
        console.error("[BG] Failed to send state:", e);
      }
    });
    port.onMessage.addListener(async (msg) => {
      console.log(`[BG] Message from ${port.name}:`, msg.type);
      switch (msg.type) {
        case "SUBSCRIBE": {
          const { coin } = msg.payload;
          await stateManager.setCoin(coin);
          break;
        }
        case "GET_STATE": {
          const state = stateManager.getState();
          if (state) {
            port.postMessage({ type: "STATE_UPDATE", payload: state });
          }
          break;
        }
      }
    });
    port.onDisconnect.addListener(() => {
      console.log(`[BG] Port disconnected: ${port.name}`);
      connectedPorts.delete(portId);
      unsubscribe();
    });
  });
  chrome.runtime.onInstalled.addListener((details) => {
    console.log("[BG] Extension installed:", details.reason);
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  });
  console.log("[BG] Service worker started");
})();
//# sourceMappingURL=index.js.map
