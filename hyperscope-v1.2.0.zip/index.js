(function() {
  "use strict";
  var n, l$1, u$2, i$1, o$1, r$1, e$1, f$2, c$1, s$1, a$1, p$1 = {}, v$1 = [], y$1 = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i, d$1 = Array.isArray;
  function w$1(n2, l2) {
    for (var u2 in l2) n2[u2] = l2[u2];
    return n2;
  }
  function g(n2) {
    n2 && n2.parentNode && n2.parentNode.removeChild(n2);
  }
  function _(l2, u2, t2) {
    var i2, o2, r2, e2 = {};
    for (r2 in u2) "key" == r2 ? i2 = u2[r2] : "ref" == r2 ? o2 = u2[r2] : e2[r2] = u2[r2];
    if (arguments.length > 2 && (e2.children = arguments.length > 3 ? n.call(arguments, 2) : t2), "function" == typeof l2 && null != l2.defaultProps) for (r2 in l2.defaultProps) void 0 === e2[r2] && (e2[r2] = l2.defaultProps[r2]);
    return m$1(l2, e2, i2, o2, null);
  }
  function m$1(n2, t2, i2, o2, r2) {
    var e2 = { type: n2, props: t2, key: i2, ref: o2, __k: null, __: null, __b: 0, __e: null, __c: null, constructor: void 0, __v: null == r2 ? ++u$2 : r2, __i: -1, __u: 0 };
    return null == r2 && null != l$1.vnode && l$1.vnode(e2), e2;
  }
  function k$1(n2) {
    return n2.children;
  }
  function x(n2, l2) {
    this.props = n2, this.context = l2;
  }
  function S(n2, l2) {
    if (null == l2) return n2.__ ? S(n2.__, n2.__i + 1) : null;
    for (var u2; l2 < n2.__k.length; l2++) if (null != (u2 = n2.__k[l2]) && null != u2.__e) return u2.__e;
    return "function" == typeof n2.type ? S(n2) : null;
  }
  function C$1(n2) {
    var l2, u2;
    if (null != (n2 = n2.__) && null != n2.__c) {
      for (n2.__e = n2.__c.base = null, l2 = 0; l2 < n2.__k.length; l2++) if (null != (u2 = n2.__k[l2]) && null != u2.__e) {
        n2.__e = n2.__c.base = u2.__e;
        break;
      }
      return C$1(n2);
    }
  }
  function M(n2) {
    (!n2.__d && (n2.__d = true) && i$1.push(n2) && !$.__r++ || o$1 != l$1.debounceRendering) && ((o$1 = l$1.debounceRendering) || r$1)($);
  }
  function $() {
    for (var n2, u2, t2, o2, r2, f2, c2, s2 = 1; i$1.length; ) i$1.length > s2 && i$1.sort(e$1), n2 = i$1.shift(), s2 = i$1.length, n2.__d && (t2 = void 0, o2 = void 0, r2 = (o2 = (u2 = n2).__v).__e, f2 = [], c2 = [], u2.__P && ((t2 = w$1({}, o2)).__v = o2.__v + 1, l$1.vnode && l$1.vnode(t2), O(u2.__P, t2, o2, u2.__n, u2.__P.namespaceURI, 32 & o2.__u ? [r2] : null, f2, null == r2 ? S(o2) : r2, !!(32 & o2.__u), c2), t2.__v = o2.__v, t2.__.__k[t2.__i] = t2, N(f2, t2, c2), o2.__e = o2.__ = null, t2.__e != r2 && C$1(t2)));
    $.__r = 0;
  }
  function I(n2, l2, u2, t2, i2, o2, r2, e2, f2, c2, s2) {
    var a2, h2, y2, d2, w2, g2, _2, m2 = t2 && t2.__k || v$1, b = l2.length;
    for (f2 = P(u2, l2, m2, f2, b), a2 = 0; a2 < b; a2++) null != (y2 = u2.__k[a2]) && (h2 = -1 == y2.__i ? p$1 : m2[y2.__i] || p$1, y2.__i = a2, g2 = O(n2, y2, h2, i2, o2, r2, e2, f2, c2, s2), d2 = y2.__e, y2.ref && h2.ref != y2.ref && (h2.ref && B$1(h2.ref, null, y2), s2.push(y2.ref, y2.__c || d2, y2)), null == w2 && null != d2 && (w2 = d2), (_2 = !!(4 & y2.__u)) || h2.__k === y2.__k ? f2 = A(y2, f2, n2, _2) : "function" == typeof y2.type && void 0 !== g2 ? f2 = g2 : d2 && (f2 = d2.nextSibling), y2.__u &= -7);
    return u2.__e = w2, f2;
  }
  function P(n2, l2, u2, t2, i2) {
    var o2, r2, e2, f2, c2, s2 = u2.length, a2 = s2, h2 = 0;
    for (n2.__k = new Array(i2), o2 = 0; o2 < i2; o2++) null != (r2 = l2[o2]) && "boolean" != typeof r2 && "function" != typeof r2 ? ("string" == typeof r2 || "number" == typeof r2 || "bigint" == typeof r2 || r2.constructor == String ? r2 = n2.__k[o2] = m$1(null, r2, null, null, null) : d$1(r2) ? r2 = n2.__k[o2] = m$1(k$1, { children: r2 }, null, null, null) : void 0 === r2.constructor && r2.__b > 0 ? r2 = n2.__k[o2] = m$1(r2.type, r2.props, r2.key, r2.ref ? r2.ref : null, r2.__v) : n2.__k[o2] = r2, f2 = o2 + h2, r2.__ = n2, r2.__b = n2.__b + 1, e2 = null, -1 != (c2 = r2.__i = L(r2, u2, f2, a2)) && (a2--, (e2 = u2[c2]) && (e2.__u |= 2)), null == e2 || null == e2.__v ? (-1 == c2 && (i2 > s2 ? h2-- : i2 < s2 && h2++), "function" != typeof r2.type && (r2.__u |= 4)) : c2 != f2 && (c2 == f2 - 1 ? h2-- : c2 == f2 + 1 ? h2++ : (c2 > f2 ? h2-- : h2++, r2.__u |= 4))) : n2.__k[o2] = null;
    if (a2) for (o2 = 0; o2 < s2; o2++) null != (e2 = u2[o2]) && 0 == (2 & e2.__u) && (e2.__e == t2 && (t2 = S(e2)), D$1(e2, e2));
    return t2;
  }
  function A(n2, l2, u2, t2) {
    var i2, o2;
    if ("function" == typeof n2.type) {
      for (i2 = n2.__k, o2 = 0; i2 && o2 < i2.length; o2++) i2[o2] && (i2[o2].__ = n2, l2 = A(i2[o2], l2, u2, t2));
      return l2;
    }
    n2.__e != l2 && (t2 && (l2 && n2.type && !l2.parentNode && (l2 = S(n2)), u2.insertBefore(n2.__e, l2 || null)), l2 = n2.__e);
    do {
      l2 = l2 && l2.nextSibling;
    } while (null != l2 && 8 == l2.nodeType);
    return l2;
  }
  function L(n2, l2, u2, t2) {
    var i2, o2, r2, e2 = n2.key, f2 = n2.type, c2 = l2[u2], s2 = null != c2 && 0 == (2 & c2.__u);
    if (null === c2 && null == e2 || s2 && e2 == c2.key && f2 == c2.type) return u2;
    if (t2 > (s2 ? 1 : 0)) {
      for (i2 = u2 - 1, o2 = u2 + 1; i2 >= 0 || o2 < l2.length; ) if (null != (c2 = l2[r2 = i2 >= 0 ? i2-- : o2++]) && 0 == (2 & c2.__u) && e2 == c2.key && f2 == c2.type) return r2;
    }
    return -1;
  }
  function T(n2, l2, u2) {
    "-" == l2[0] ? n2.setProperty(l2, null == u2 ? "" : u2) : n2[l2] = null == u2 ? "" : "number" != typeof u2 || y$1.test(l2) ? u2 : u2 + "px";
  }
  function j$1(n2, l2, u2, t2, i2) {
    var o2, r2;
    n: if ("style" == l2) if ("string" == typeof u2) n2.style.cssText = u2;
    else {
      if ("string" == typeof t2 && (n2.style.cssText = t2 = ""), t2) for (l2 in t2) u2 && l2 in u2 || T(n2.style, l2, "");
      if (u2) for (l2 in u2) t2 && u2[l2] == t2[l2] || T(n2.style, l2, u2[l2]);
    }
    else if ("o" == l2[0] && "n" == l2[1]) o2 = l2 != (l2 = l2.replace(f$2, "$1")), r2 = l2.toLowerCase(), l2 = r2 in n2 || "onFocusOut" == l2 || "onFocusIn" == l2 ? r2.slice(2) : l2.slice(2), n2.l || (n2.l = {}), n2.l[l2 + o2] = u2, u2 ? t2 ? u2.u = t2.u : (u2.u = c$1, n2.addEventListener(l2, o2 ? a$1 : s$1, o2)) : n2.removeEventListener(l2, o2 ? a$1 : s$1, o2);
    else {
      if ("http://www.w3.org/2000/svg" == i2) l2 = l2.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
      else if ("width" != l2 && "height" != l2 && "href" != l2 && "list" != l2 && "form" != l2 && "tabIndex" != l2 && "download" != l2 && "rowSpan" != l2 && "colSpan" != l2 && "role" != l2 && "popover" != l2 && l2 in n2) try {
        n2[l2] = null == u2 ? "" : u2;
        break n;
      } catch (n3) {
      }
      "function" == typeof u2 || (null == u2 || false === u2 && "-" != l2[4] ? n2.removeAttribute(l2) : n2.setAttribute(l2, "popover" == l2 && 1 == u2 ? "" : u2));
    }
  }
  function F(n2) {
    return function(u2) {
      if (this.l) {
        var t2 = this.l[u2.type + n2];
        if (null == u2.t) u2.t = c$1++;
        else if (u2.t < t2.u) return;
        return t2(l$1.event ? l$1.event(u2) : u2);
      }
    };
  }
  function O(n2, u2, t2, i2, o2, r2, e2, f2, c2, s2) {
    var a2, h2, p2, v2, y2, _2, m2, b, S2, C2, M2, $2, P2, A2, H, L2, T2, j2 = u2.type;
    if (void 0 !== u2.constructor) return null;
    128 & t2.__u && (c2 = !!(32 & t2.__u), r2 = [f2 = u2.__e = t2.__e]), (a2 = l$1.__b) && a2(u2);
    n: if ("function" == typeof j2) try {
      if (b = u2.props, S2 = "prototype" in j2 && j2.prototype.render, C2 = (a2 = j2.contextType) && i2[a2.__c], M2 = a2 ? C2 ? C2.props.value : a2.__ : i2, t2.__c ? m2 = (h2 = u2.__c = t2.__c).__ = h2.__E : (S2 ? u2.__c = h2 = new j2(b, M2) : (u2.__c = h2 = new x(b, M2), h2.constructor = j2, h2.render = E), C2 && C2.sub(h2), h2.state || (h2.state = {}), h2.__n = i2, p2 = h2.__d = true, h2.__h = [], h2._sb = []), S2 && null == h2.__s && (h2.__s = h2.state), S2 && null != j2.getDerivedStateFromProps && (h2.__s == h2.state && (h2.__s = w$1({}, h2.__s)), w$1(h2.__s, j2.getDerivedStateFromProps(b, h2.__s))), v2 = h2.props, y2 = h2.state, h2.__v = u2, p2) S2 && null == j2.getDerivedStateFromProps && null != h2.componentWillMount && h2.componentWillMount(), S2 && null != h2.componentDidMount && h2.__h.push(h2.componentDidMount);
      else {
        if (S2 && null == j2.getDerivedStateFromProps && b !== v2 && null != h2.componentWillReceiveProps && h2.componentWillReceiveProps(b, M2), u2.__v == t2.__v || !h2.__e && null != h2.shouldComponentUpdate && false === h2.shouldComponentUpdate(b, h2.__s, M2)) {
          for (u2.__v != t2.__v && (h2.props = b, h2.state = h2.__s, h2.__d = false), u2.__e = t2.__e, u2.__k = t2.__k, u2.__k.some(function(n3) {
            n3 && (n3.__ = u2);
          }), $2 = 0; $2 < h2._sb.length; $2++) h2.__h.push(h2._sb[$2]);
          h2._sb = [], h2.__h.length && e2.push(h2);
          break n;
        }
        null != h2.componentWillUpdate && h2.componentWillUpdate(b, h2.__s, M2), S2 && null != h2.componentDidUpdate && h2.__h.push(function() {
          h2.componentDidUpdate(v2, y2, _2);
        });
      }
      if (h2.context = M2, h2.props = b, h2.__P = n2, h2.__e = false, P2 = l$1.__r, A2 = 0, S2) {
        for (h2.state = h2.__s, h2.__d = false, P2 && P2(u2), a2 = h2.render(h2.props, h2.state, h2.context), H = 0; H < h2._sb.length; H++) h2.__h.push(h2._sb[H]);
        h2._sb = [];
      } else do {
        h2.__d = false, P2 && P2(u2), a2 = h2.render(h2.props, h2.state, h2.context), h2.state = h2.__s;
      } while (h2.__d && ++A2 < 25);
      h2.state = h2.__s, null != h2.getChildContext && (i2 = w$1(w$1({}, i2), h2.getChildContext())), S2 && !p2 && null != h2.getSnapshotBeforeUpdate && (_2 = h2.getSnapshotBeforeUpdate(v2, y2)), L2 = a2, null != a2 && a2.type === k$1 && null == a2.key && (L2 = V(a2.props.children)), f2 = I(n2, d$1(L2) ? L2 : [L2], u2, t2, i2, o2, r2, e2, f2, c2, s2), h2.base = u2.__e, u2.__u &= -161, h2.__h.length && e2.push(h2), m2 && (h2.__E = h2.__ = null);
    } catch (n3) {
      if (u2.__v = null, c2 || null != r2) if (n3.then) {
        for (u2.__u |= c2 ? 160 : 128; f2 && 8 == f2.nodeType && f2.nextSibling; ) f2 = f2.nextSibling;
        r2[r2.indexOf(f2)] = null, u2.__e = f2;
      } else {
        for (T2 = r2.length; T2--; ) g(r2[T2]);
        z$1(u2);
      }
      else u2.__e = t2.__e, u2.__k = t2.__k, n3.then || z$1(u2);
      l$1.__e(n3, u2, t2);
    }
    else null == r2 && u2.__v == t2.__v ? (u2.__k = t2.__k, u2.__e = t2.__e) : f2 = u2.__e = q(t2.__e, u2, t2, i2, o2, r2, e2, c2, s2);
    return (a2 = l$1.diffed) && a2(u2), 128 & u2.__u ? void 0 : f2;
  }
  function z$1(n2) {
    n2 && n2.__c && (n2.__c.__e = true), n2 && n2.__k && n2.__k.forEach(z$1);
  }
  function N(n2, u2, t2) {
    for (var i2 = 0; i2 < t2.length; i2++) B$1(t2[i2], t2[++i2], t2[++i2]);
    l$1.__c && l$1.__c(u2, n2), n2.some(function(u3) {
      try {
        n2 = u3.__h, u3.__h = [], n2.some(function(n3) {
          n3.call(u3);
        });
      } catch (n3) {
        l$1.__e(n3, u3.__v);
      }
    });
  }
  function V(n2) {
    return "object" != typeof n2 || null == n2 || n2.__b && n2.__b > 0 ? n2 : d$1(n2) ? n2.map(V) : w$1({}, n2);
  }
  function q(u2, t2, i2, o2, r2, e2, f2, c2, s2) {
    var a2, h2, v2, y2, w2, _2, m2, b = i2.props || p$1, k2 = t2.props, x2 = t2.type;
    if ("svg" == x2 ? r2 = "http://www.w3.org/2000/svg" : "math" == x2 ? r2 = "http://www.w3.org/1998/Math/MathML" : r2 || (r2 = "http://www.w3.org/1999/xhtml"), null != e2) {
      for (a2 = 0; a2 < e2.length; a2++) if ((w2 = e2[a2]) && "setAttribute" in w2 == !!x2 && (x2 ? w2.localName == x2 : 3 == w2.nodeType)) {
        u2 = w2, e2[a2] = null;
        break;
      }
    }
    if (null == u2) {
      if (null == x2) return document.createTextNode(k2);
      u2 = document.createElementNS(r2, x2, k2.is && k2), c2 && (l$1.__m && l$1.__m(t2, e2), c2 = false), e2 = null;
    }
    if (null == x2) b === k2 || c2 && u2.data == k2 || (u2.data = k2);
    else {
      if (e2 = e2 && n.call(u2.childNodes), !c2 && null != e2) for (b = {}, a2 = 0; a2 < u2.attributes.length; a2++) b[(w2 = u2.attributes[a2]).name] = w2.value;
      for (a2 in b) if (w2 = b[a2], "children" == a2) ;
      else if ("dangerouslySetInnerHTML" == a2) v2 = w2;
      else if (!(a2 in k2)) {
        if ("value" == a2 && "defaultValue" in k2 || "checked" == a2 && "defaultChecked" in k2) continue;
        j$1(u2, a2, null, w2, r2);
      }
      for (a2 in k2) w2 = k2[a2], "children" == a2 ? y2 = w2 : "dangerouslySetInnerHTML" == a2 ? h2 = w2 : "value" == a2 ? _2 = w2 : "checked" == a2 ? m2 = w2 : c2 && "function" != typeof w2 || b[a2] === w2 || j$1(u2, a2, w2, b[a2], r2);
      if (h2) c2 || v2 && (h2.__html == v2.__html || h2.__html == u2.innerHTML) || (u2.innerHTML = h2.__html), t2.__k = [];
      else if (v2 && (u2.innerHTML = ""), I("template" == t2.type ? u2.content : u2, d$1(y2) ? y2 : [y2], t2, i2, o2, "foreignObject" == x2 ? "http://www.w3.org/1999/xhtml" : r2, e2, f2, e2 ? e2[0] : i2.__k && S(i2, 0), c2, s2), null != e2) for (a2 = e2.length; a2--; ) g(e2[a2]);
      c2 || (a2 = "value", "progress" == x2 && null == _2 ? u2.removeAttribute("value") : null != _2 && (_2 !== u2[a2] || "progress" == x2 && !_2 || "option" == x2 && _2 != b[a2]) && j$1(u2, a2, _2, b[a2], r2), a2 = "checked", null != m2 && m2 != u2[a2] && j$1(u2, a2, m2, b[a2], r2));
    }
    return u2;
  }
  function B$1(n2, u2, t2) {
    try {
      if ("function" == typeof n2) {
        var i2 = "function" == typeof n2.__u;
        i2 && n2.__u(), i2 && null == u2 || (n2.__u = n2(u2));
      } else n2.current = u2;
    } catch (n3) {
      l$1.__e(n3, t2);
    }
  }
  function D$1(n2, u2, t2) {
    var i2, o2;
    if (l$1.unmount && l$1.unmount(n2), (i2 = n2.ref) && (i2.current && i2.current != n2.__e || B$1(i2, null, u2)), null != (i2 = n2.__c)) {
      if (i2.componentWillUnmount) try {
        i2.componentWillUnmount();
      } catch (n3) {
        l$1.__e(n3, u2);
      }
      i2.base = i2.__P = null;
    }
    if (i2 = n2.__k) for (o2 = 0; o2 < i2.length; o2++) i2[o2] && D$1(i2[o2], u2, t2 || "function" != typeof n2.type);
    t2 || g(n2.__e), n2.__c = n2.__ = n2.__e = void 0;
  }
  function E(n2, l2, u2) {
    return this.constructor(n2, u2);
  }
  function G(u2, t2, i2) {
    var o2, r2, e2, f2;
    t2 == document && (t2 = document.documentElement), l$1.__ && l$1.__(u2, t2), r2 = (o2 = false) ? null : t2.__k, e2 = [], f2 = [], O(t2, u2 = t2.__k = _(k$1, null, [u2]), r2 || p$1, p$1, t2.namespaceURI, r2 ? null : t2.firstChild ? n.call(t2.childNodes) : null, e2, r2 ? r2.__e : t2.firstChild, o2, f2), N(e2, u2, f2);
  }
  n = v$1.slice, l$1 = { __e: function(n2, l2, u2, t2) {
    for (var i2, o2, r2; l2 = l2.__; ) if ((i2 = l2.__c) && !i2.__) try {
      if ((o2 = i2.constructor) && null != o2.getDerivedStateFromError && (i2.setState(o2.getDerivedStateFromError(n2)), r2 = i2.__d), null != i2.componentDidCatch && (i2.componentDidCatch(n2, t2 || {}), r2 = i2.__d), r2) return i2.__E = i2;
    } catch (l3) {
      n2 = l3;
    }
    throw n2;
  } }, u$2 = 0, x.prototype.setState = function(n2, l2) {
    var u2;
    u2 = null != this.__s && this.__s != this.state ? this.__s : this.__s = w$1({}, this.state), "function" == typeof n2 && (n2 = n2(w$1({}, u2), this.props)), n2 && w$1(u2, n2), null != n2 && this.__v && (l2 && this._sb.push(l2), M(this));
  }, x.prototype.forceUpdate = function(n2) {
    this.__v && (this.__e = true, n2 && this.__h.push(n2), M(this));
  }, x.prototype.render = k$1, i$1 = [], r$1 = "function" == typeof Promise ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, e$1 = function(n2, l2) {
    return n2.__v.__b - l2.__v.__b;
  }, $.__r = 0, f$2 = /(PointerCapture)$|Capture$/i, c$1 = 0, s$1 = F(false), a$1 = F(true);
  var f$1 = 0;
  function u$1(e2, t2, n2, o2, i2, u2) {
    t2 || (t2 = {});
    var a2, c2, p2 = t2;
    if ("ref" in p2) for (c2 in p2 = {}, t2) "ref" == c2 ? a2 = t2[c2] : p2[c2] = t2[c2];
    var l2 = { type: e2, props: p2, key: n2, ref: a2, __k: null, __: null, __b: 0, __e: null, __c: null, constructor: void 0, __v: --f$1, __i: -1, __u: 0, __source: i2, __self: u2 };
    if ("function" == typeof e2 && (a2 = e2.defaultProps)) for (c2 in a2) void 0 === p2[c2] && (p2[c2] = a2[c2]);
    return l$1.vnode && l$1.vnode(l2), l2;
  }
  var t, r, u, i, o = 0, f = [], c = l$1, e = c.__b, a = c.__r, v = c.diffed, l = c.__c, m = c.unmount, s = c.__;
  function p(n2, t2) {
    c.__h && c.__h(r, n2, o || t2), o = 0;
    var u2 = r.__H || (r.__H = { __: [], __h: [] });
    return n2 >= u2.__.length && u2.__.push({}), u2.__[n2];
  }
  function d(n2) {
    return o = 1, h(D, n2);
  }
  function h(n2, u2, i2) {
    var o2 = p(t++, 2);
    if (o2.t = n2, !o2.__c && (o2.__ = [D(void 0, u2), function(n3) {
      var t2 = o2.__N ? o2.__N[0] : o2.__[0], r2 = o2.t(t2, n3);
      t2 !== r2 && (o2.__N = [r2, o2.__[1]], o2.__c.setState({}));
    }], o2.__c = r, !r.__f)) {
      var f2 = function(n3, t2, r2) {
        if (!o2.__c.__H) return true;
        var u3 = o2.__c.__H.__.filter(function(n4) {
          return !!n4.__c;
        });
        if (u3.every(function(n4) {
          return !n4.__N;
        })) return !c2 || c2.call(this, n3, t2, r2);
        var i3 = o2.__c.props !== n3;
        return u3.forEach(function(n4) {
          if (n4.__N) {
            var t3 = n4.__[0];
            n4.__ = n4.__N, n4.__N = void 0, t3 !== n4.__[0] && (i3 = true);
          }
        }), c2 && c2.call(this, n3, t2, r2) || i3;
      };
      r.__f = true;
      var c2 = r.shouldComponentUpdate, e2 = r.componentWillUpdate;
      r.componentWillUpdate = function(n3, t2, r2) {
        if (this.__e) {
          var u3 = c2;
          c2 = void 0, f2(n3, t2, r2), c2 = u3;
        }
        e2 && e2.call(this, n3, t2, r2);
      }, r.shouldComponentUpdate = f2;
    }
    return o2.__N || o2.__;
  }
  function y(n2, u2) {
    var i2 = p(t++, 3);
    !c.__s && C(i2.__H, u2) && (i2.__ = n2, i2.u = u2, r.__H.__h.push(i2));
  }
  function j() {
    for (var n2; n2 = f.shift(); ) if (n2.__P && n2.__H) try {
      n2.__H.__h.forEach(z), n2.__H.__h.forEach(B), n2.__H.__h = [];
    } catch (t2) {
      n2.__H.__h = [], c.__e(t2, n2.__v);
    }
  }
  c.__b = function(n2) {
    r = null, e && e(n2);
  }, c.__ = function(n2, t2) {
    n2 && t2.__k && t2.__k.__m && (n2.__m = t2.__k.__m), s && s(n2, t2);
  }, c.__r = function(n2) {
    a && a(n2), t = 0;
    var i2 = (r = n2.__c).__H;
    i2 && (u === r ? (i2.__h = [], r.__h = [], i2.__.forEach(function(n3) {
      n3.__N && (n3.__ = n3.__N), n3.u = n3.__N = void 0;
    })) : (i2.__h.forEach(z), i2.__h.forEach(B), i2.__h = [], t = 0)), u = r;
  }, c.diffed = function(n2) {
    v && v(n2);
    var t2 = n2.__c;
    t2 && t2.__H && (t2.__H.__h.length && (1 !== f.push(t2) && i === c.requestAnimationFrame || ((i = c.requestAnimationFrame) || w)(j)), t2.__H.__.forEach(function(n3) {
      n3.u && (n3.__H = n3.u), n3.u = void 0;
    })), u = r = null;
  }, c.__c = function(n2, t2) {
    t2.some(function(n3) {
      try {
        n3.__h.forEach(z), n3.__h = n3.__h.filter(function(n4) {
          return !n4.__ || B(n4);
        });
      } catch (r2) {
        t2.some(function(n4) {
          n4.__h && (n4.__h = []);
        }), t2 = [], c.__e(r2, n3.__v);
      }
    }), l && l(n2, t2);
  }, c.unmount = function(n2) {
    m && m(n2);
    var t2, r2 = n2.__c;
    r2 && r2.__H && (r2.__H.__.forEach(function(n3) {
      try {
        z(n3);
      } catch (n4) {
        t2 = n4;
      }
    }), r2.__H = void 0, t2 && c.__e(t2, r2.__v));
  };
  var k = "function" == typeof requestAnimationFrame;
  function w(n2) {
    var t2, r2 = function() {
      clearTimeout(u2), k && cancelAnimationFrame(t2), setTimeout(n2);
    }, u2 = setTimeout(r2, 35);
    k && (t2 = requestAnimationFrame(r2));
  }
  function z(n2) {
    var t2 = r, u2 = n2.__c;
    "function" == typeof u2 && (n2.__c = void 0, u2()), r = t2;
  }
  function B(n2) {
    var t2 = r;
    n2.__c = n2.__(), r = t2;
  }
  function C(n2, t2) {
    return !n2 || n2.length !== t2.length || t2.some(function(t3, r2) {
      return t3 !== n2[r2];
    });
  }
  function D(n2, t2) {
    return "function" == typeof t2 ? t2(n2) : t2;
  }
  function formatNumber(n2, decimals = 2) {
    if (Math.abs(n2) >= 1e9) return (n2 / 1e9).toFixed(decimals) + "B";
    if (Math.abs(n2) >= 1e6) return (n2 / 1e6).toFixed(decimals) + "M";
    if (Math.abs(n2) >= 1e3) return (n2 / 1e3).toFixed(decimals) + "K";
    return n2.toFixed(decimals);
  }
  function formatPct(n2, decimals = 2) {
    return (n2 * 100).toFixed(decimals) + "%";
  }
  const TOOLTIPS = {
    price: "Current mark price of the asset",
    openInterest: "Total value of all open positions",
    bookImbalance: "Difference between bid and ask depth. Positive = more buyers",
    funding: "Annualized funding rate. Positive = longs pay shorts",
    cvd: "Cumulative Volume Delta - net buying vs selling pressure over time",
    whaleActivity: "Large trades (>$50K) detected in recent order flow",
    buyIntensity: "Percentage of volume from aggressive buyers",
    sellIntensity: "Percentage of volume from aggressive sellers",
    oiDivergence: "Relationship between price movement and open interest changes",
    pressureMap: "Estimated liquidation volume at price levels ±5% from current",
    liqGravity: "Which direction has more liquidation clusters to attract price",
    compression: "Volatility squeeze signals - low volatility often precedes big moves",
    trapRisk: "Risk of a position squeeze based on crowding and funding",
    rangeNarrowing: "Price range getting tighter (Bollinger Bands squeezing)",
    oiRising: "Open interest increasing while price consolidates",
    fundingExtreme: "Funding rate significantly above/below normal",
    volumeDeclining: "Trading volume decreasing during consolidation",
    bbWidth: "Bollinger Band width percentile - lower = more compressed"
  };
  const DEFAULT_SETTINGS = {
    showCVD: true,
    showWhaleActivity: true,
    showOIDivergence: true,
    showPressureMap: true,
    showGravity: true,
    showCompression: true,
    showTrapRisk: true,
    showInsight: true
  };
  function generateInsight(state) {
    const { cvd, compression, gravity, trap, tape, oiDivergence, market } = state;
    if (compression.isCompressed && gravity.score === "HIGH_BELOW" && trap.direction === "long") {
      return {
        type: "bearish",
        title: "Breakdown Setup",
        message: "Compression + liquidations clustered below + longs crowded. Breakdown could trigger cascade."
      };
    }
    if (compression.isCompressed && gravity.score === "HIGH_ABOVE" && trap.direction === "short") {
      return {
        type: "bullish",
        title: "Breakout Setup",
        message: "Compression + liquidations clustered above + shorts crowded. Breakout could trigger squeeze."
      };
    }
    if (cvd.divergence === "bullish" && trap.elevated && trap.direction === "short") {
      return {
        type: "bullish",
        title: "Short Squeeze Risk",
        message: "Bullish CVD divergence while shorts are crowded. Potential squeeze setup forming."
      };
    }
    if (cvd.divergence === "bearish" && trap.elevated && trap.direction === "long") {
      return {
        type: "bearish",
        title: "Long Squeeze Risk",
        message: "Bearish CVD divergence while longs are crowded. Potential flush setup forming."
      };
    }
    if (tape.whaleBuyVolume > tape.whaleSellVolume * 2 && market.fundingAnnualized < -0.3) {
      return {
        type: "bullish",
        title: "Smart Money Accumulation",
        message: "Whales aggressively buying while funding is negative. Potential accumulation phase."
      };
    }
    if (tape.whaleSellVolume > tape.whaleBuyVolume * 2 && market.fundingAnnualized > 0.3) {
      return {
        type: "bearish",
        title: "Smart Money Distribution",
        message: "Whales aggressively selling while funding is positive. Potential distribution phase."
      };
    }
    if (oiDivergence.pattern === "short_covering" && oiDivergence.strength !== "weak") {
      return {
        type: "bullish",
        title: "Short Covering Rally",
        message: "Price rising while OI falling. Shorts closing positions, not new longs entering."
      };
    }
    if (oiDivergence.pattern === "long_liquidation" && oiDivergence.strength !== "weak") {
      return {
        type: "bearish",
        title: "Long Liquidation Cascade",
        message: "Price falling while OI falling. Longs being forced out, watch for capitulation."
      };
    }
    if (Math.abs(market.fundingAnnualized) > 1) {
      const direction = market.fundingAnnualized > 0 ? "longs" : "shorts";
      const opposite = market.fundingAnnualized > 0 ? "short" : "long";
      return {
        type: "warning",
        title: "Extreme Funding",
        message: `${direction.charAt(0).toUpperCase() + direction.slice(1)} paying ${Math.abs(market.fundingAnnualized * 100).toFixed(0)}% annualized. Crowded trade, consider ${opposite} bias.`
      };
    }
    if (cvd.momentum === "strong_buy" && tape.buyIntensity > 65) {
      return {
        type: "bullish",
        title: "Strong Buying Pressure",
        message: "Aggressive buying across timeframes. Order flow strongly favors bulls."
      };
    }
    if (cvd.momentum === "strong_sell" && tape.sellIntensity > 65) {
      return {
        type: "bearish",
        title: "Strong Selling Pressure",
        message: "Aggressive selling across timeframes. Order flow strongly favors bears."
      };
    }
    if (compression.isCompressed) {
      return {
        type: "warning",
        title: "Volatility Compression",
        message: "Multiple compression signals active. Expansion likely soon, direction uncertain."
      };
    }
    if (trap.elevated) {
      const crowded = trap.direction === "long" ? "Longs" : "Shorts";
      return {
        type: "warning",
        title: `${crowded} Crowded`,
        message: `${crowded} appear crowded based on OI and funding. Elevated squeeze risk.`
      };
    }
    return null;
  }
  const SettingsIcon = () => /* @__PURE__ */ u$1("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "2", children: [
    /* @__PURE__ */ u$1("circle", { cx: "12", cy: "12", r: "3" }),
    /* @__PURE__ */ u$1("path", { d: "M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42" })
  ] });
  const CloseIcon = () => /* @__PURE__ */ u$1("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "2", children: /* @__PURE__ */ u$1("path", { d: "M18 6L6 18M6 6l12 12" }) });
  const InfoIcon = ({ tooltip, className = "" }) => /* @__PURE__ */ u$1("span", { class: `hl-tooltip hl-info-icon ${className}`, "data-tooltip": tooltip, children: "?" });
  const Toggle = ({ checked, onChange, id }) => /* @__PURE__ */ u$1("label", { class: "hl-toggle", children: [
    /* @__PURE__ */ u$1("input", { type: "checkbox", checked, onChange: (e2) => onChange(e2.target.checked), id }),
    /* @__PURE__ */ u$1("span", { class: "hl-toggle-slider" })
  ] });
  const SettingsPanel = ({
    open,
    onClose,
    settings,
    onSettingsChange,
    onReset
  }) => /* @__PURE__ */ u$1("div", { class: `hl-settings-overlay ${open ? "open" : ""}`, onClick: onClose, children: /* @__PURE__ */ u$1("div", { class: "hl-settings-panel", onClick: (e2) => e2.stopPropagation(), children: [
    /* @__PURE__ */ u$1("div", { class: "hl-settings-header", children: [
      /* @__PURE__ */ u$1("span", { class: "hl-settings-title", children: "Settings" }),
      /* @__PURE__ */ u$1("button", { class: "hl-settings-close", onClick: onClose, children: /* @__PURE__ */ u$1(CloseIcon, {}) })
    ] }),
    /* @__PURE__ */ u$1("div", { class: "hl-settings-content", children: /* @__PURE__ */ u$1("div", { class: "hl-settings-section", children: [
      /* @__PURE__ */ u$1("div", { class: "hl-settings-section-title", children: "Visible Sections" }),
      /* @__PURE__ */ u$1("div", { class: "hl-settings-item", children: [
        /* @__PURE__ */ u$1("div", { children: [
          /* @__PURE__ */ u$1("div", { class: "hl-settings-item-label", children: "Order Flow (CVD)" }),
          /* @__PURE__ */ u$1("div", { class: "hl-settings-item-desc", children: "Cumulative volume delta analysis" })
        ] }),
        /* @__PURE__ */ u$1(Toggle, { checked: settings.showCVD, onChange: (v2) => onSettingsChange("showCVD", v2), id: "showCVD" })
      ] }),
      /* @__PURE__ */ u$1("div", { class: "hl-settings-item", children: [
        /* @__PURE__ */ u$1("div", { children: [
          /* @__PURE__ */ u$1("div", { class: "hl-settings-item-label", children: "Whale Activity" }),
          /* @__PURE__ */ u$1("div", { class: "hl-settings-item-desc", children: "Large trade detection" })
        ] }),
        /* @__PURE__ */ u$1(Toggle, { checked: settings.showWhaleActivity, onChange: (v2) => onSettingsChange("showWhaleActivity", v2), id: "showWhaleActivity" })
      ] }),
      /* @__PURE__ */ u$1("div", { class: "hl-settings-item", children: [
        /* @__PURE__ */ u$1("div", { children: [
          /* @__PURE__ */ u$1("div", { class: "hl-settings-item-label", children: "OI × Price" }),
          /* @__PURE__ */ u$1("div", { class: "hl-settings-item-desc", children: "Open interest divergence" })
        ] }),
        /* @__PURE__ */ u$1(Toggle, { checked: settings.showOIDivergence, onChange: (v2) => onSettingsChange("showOIDivergence", v2), id: "showOIDivergence" })
      ] }),
      /* @__PURE__ */ u$1("div", { class: "hl-settings-item", children: [
        /* @__PURE__ */ u$1("div", { children: [
          /* @__PURE__ */ u$1("div", { class: "hl-settings-item-label", children: "Pressure Map" }),
          /* @__PURE__ */ u$1("div", { class: "hl-settings-item-desc", children: "Liquidation estimates ±5%" })
        ] }),
        /* @__PURE__ */ u$1(Toggle, { checked: settings.showPressureMap, onChange: (v2) => onSettingsChange("showPressureMap", v2), id: "showPressureMap" })
      ] }),
      /* @__PURE__ */ u$1("div", { class: "hl-settings-item", children: [
        /* @__PURE__ */ u$1("div", { children: [
          /* @__PURE__ */ u$1("div", { class: "hl-settings-item-label", children: "Liquidation Gravity" }),
          /* @__PURE__ */ u$1("div", { class: "hl-settings-item-desc", children: "Liquidation cluster direction" })
        ] }),
        /* @__PURE__ */ u$1(Toggle, { checked: settings.showGravity, onChange: (v2) => onSettingsChange("showGravity", v2), id: "showGravity" })
      ] }),
      /* @__PURE__ */ u$1("div", { class: "hl-settings-item", children: [
        /* @__PURE__ */ u$1("div", { children: [
          /* @__PURE__ */ u$1("div", { class: "hl-settings-item-label", children: "Compression" }),
          /* @__PURE__ */ u$1("div", { class: "hl-settings-item-desc", children: "Volatility squeeze signals" })
        ] }),
        /* @__PURE__ */ u$1(Toggle, { checked: settings.showCompression, onChange: (v2) => onSettingsChange("showCompression", v2), id: "showCompression" })
      ] }),
      /* @__PURE__ */ u$1("div", { class: "hl-settings-item", children: [
        /* @__PURE__ */ u$1("div", { children: [
          /* @__PURE__ */ u$1("div", { class: "hl-settings-item-label", children: "Trap Risk" }),
          /* @__PURE__ */ u$1("div", { class: "hl-settings-item-desc", children: "Position squeeze risk" })
        ] }),
        /* @__PURE__ */ u$1(Toggle, { checked: settings.showTrapRisk, onChange: (v2) => onSettingsChange("showTrapRisk", v2), id: "showTrapRisk" })
      ] }),
      /* @__PURE__ */ u$1("div", { class: "hl-settings-item", children: [
        /* @__PURE__ */ u$1("div", { children: [
          /* @__PURE__ */ u$1("div", { class: "hl-settings-item-label", children: "Signal Insight" }),
          /* @__PURE__ */ u$1("div", { class: "hl-settings-item-desc", children: "AI-like tips based on metrics" })
        ] }),
        /* @__PURE__ */ u$1(Toggle, { checked: settings.showInsight, onChange: (v2) => onSettingsChange("showInsight", v2), id: "showInsight" })
      ] })
    ] }) }),
    /* @__PURE__ */ u$1("div", { class: "hl-settings-footer", children: /* @__PURE__ */ u$1("button", { class: "hl-settings-reset", onClick: onReset, children: "Reset to Defaults" }) })
  ] }) });
  function SidePanel() {
    const [state, setState] = d(null);
    const [loading, setLoading] = d(true);
    const [collapsed, setCollapsed] = d({});
    const [settingsOpen, setSettingsOpen] = d(false);
    const [settings, setSettings] = d(DEFAULT_SETTINGS);
    y(() => {
      chrome.storage.local.get(["hlAnalyticsSettings"], (result) => {
        if (result.hlAnalyticsSettings) {
          setSettings({ ...DEFAULT_SETTINGS, ...result.hlAnalyticsSettings });
        }
      });
    }, []);
    const updateSettings = (key, value) => {
      const newSettings = { ...settings, [key]: value };
      setSettings(newSettings);
      chrome.storage.local.set({ hlAnalyticsSettings: newSettings });
    };
    const resetSettings = () => {
      setSettings(DEFAULT_SETTINGS);
      chrome.storage.local.set({ hlAnalyticsSettings: DEFAULT_SETTINGS });
    };
    y(() => {
      console.log("[SP] SidePanel mounting...");
      const port = chrome.runtime.connect({ name: "hl-sidepanel" });
      console.log("[SP] Connected to background");
      port.onMessage.addListener((msg) => {
        console.log("[SP] Received message:", msg.type, msg.payload ? "has payload" : "no payload");
        if (msg.type === "STATE_UPDATE" && msg.payload) {
          setState(msg.payload);
          setLoading(false);
        }
      });
      port.postMessage({ type: "GET_STATE" });
      console.log("[SP] Sent GET_STATE");
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        var _a, _b;
        console.log("[SP] Got tabs:", tabs.length, (_a = tabs[0]) == null ? void 0 : _a.url);
        const tab = tabs[0];
        if ((_b = tab == null ? void 0 : tab.url) == null ? void 0 : _b.includes("app.hyperliquid.xyz")) {
          const match = tab.url.match(/\/trade\/([A-Z0-9]+)/i);
          console.log("[SP] URL match:", match);
          if (match) {
            const coin = match[1].toUpperCase();
            console.log("[SP] Subscribing to coin:", coin);
            port.postMessage({ type: "SUBSCRIBE", payload: { coin } });
          }
        } else {
          console.log("[SP] Not on trade page, defaulting to BTC");
          port.postMessage({ type: "SUBSCRIBE", payload: { coin: "BTC" } });
        }
      });
      chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
        var _a;
        if ((_a = changeInfo.url) == null ? void 0 : _a.includes("app.hyperliquid.xyz")) {
          const match = changeInfo.url.match(/\/trade\/([A-Z0-9]+)/i);
          if (match) {
            port.postMessage({ type: "SUBSCRIBE", payload: { coin: match[1].toUpperCase() } });
          }
        }
      });
      return () => port.disconnect();
    }, []);
    const toggle = (section) => {
      setCollapsed((prev) => ({ ...prev, [section]: !prev[section] }));
    };
    if (loading) {
      return /* @__PURE__ */ u$1("div", { class: "hl-sidepanel", children: [
        /* @__PURE__ */ u$1("div", { class: "hl-header", children: /* @__PURE__ */ u$1("span", { class: "hl-header-title", children: "HL Analytics" }) }),
        /* @__PURE__ */ u$1("div", { class: "hl-loading", children: [
          /* @__PURE__ */ u$1("div", { class: "hl-loading-spinner" }),
          /* @__PURE__ */ u$1("span", { class: "hl-loading-text", children: "Connecting..." })
        ] })
      ] });
    }
    if (!state) {
      return /* @__PURE__ */ u$1("div", { class: "hl-sidepanel", children: [
        /* @__PURE__ */ u$1("div", { class: "hl-header", children: /* @__PURE__ */ u$1("span", { class: "hl-header-title", children: "HL Analytics" }) }),
        /* @__PURE__ */ u$1("div", { class: "hl-no-data", children: [
          /* @__PURE__ */ u$1("div", { class: "hl-no-data-icon", children: "⊘" }),
          /* @__PURE__ */ u$1("div", { class: "hl-no-data-text", children: "No data available" }),
          /* @__PURE__ */ u$1("div", { class: "hl-no-data-hint", children: "Open Hyperliquid trading page" })
        ] })
      ] });
    }
    const { market, pressure, gravity, compression, trap, orderbook, volatility, cvd, tape, oiDivergence } = state;
    const insight = generateInsight(state);
    const formatCompact = (n2) => {
      if (Math.abs(n2) >= 1e6) return (n2 / 1e6).toFixed(1) + "M";
      if (Math.abs(n2) >= 1e3) return (n2 / 1e3).toFixed(1) + "K";
      return n2.toFixed(1);
    };
    const getCvdMomentumColor = (momentum) => {
      if (momentum === "strong_buy") return "positive";
      if (momentum === "buy") return "positive";
      if (momentum === "strong_sell") return "negative";
      if (momentum === "sell") return "negative";
      return "";
    };
    const getOiPatternLabel = (pattern) => {
      switch (pattern) {
        case "short_covering":
          return "Short Covering";
        case "new_shorts":
          return "New Shorts";
        case "new_longs":
          return "New Longs";
        case "long_liquidation":
          return "Long Liquidation";
        default:
          return "Neutral";
      }
    };
    return /* @__PURE__ */ u$1("div", { class: "hl-sidepanel", children: [
      /* @__PURE__ */ u$1(
        SettingsPanel,
        {
          open: settingsOpen,
          onClose: () => setSettingsOpen(false),
          settings,
          onSettingsChange: updateSettings,
          onReset: resetSettings
        }
      ),
      /* @__PURE__ */ u$1("div", { class: "hl-header", children: [
        /* @__PURE__ */ u$1("span", { class: "hl-header-title", children: "HL Analytics" }),
        /* @__PURE__ */ u$1("div", { style: "display: flex; align-items: center; gap: 8px;", children: [
          /* @__PURE__ */ u$1("div", { class: "hl-header-coin", children: [
            /* @__PURE__ */ u$1("span", { class: "live-dot" }),
            /* @__PURE__ */ u$1("span", { children: state.coin })
          ] }),
          /* @__PURE__ */ u$1("button", { class: "hl-settings-btn", onClick: () => setSettingsOpen(true), title: "Settings", children: /* @__PURE__ */ u$1(SettingsIcon, {}) })
        ] })
      ] }),
      /* @__PURE__ */ u$1("div", { class: "hl-stats", children: [
        /* @__PURE__ */ u$1("div", { class: "hl-stat hl-tooltip", "data-tooltip": TOOLTIPS.price, children: [
          /* @__PURE__ */ u$1("div", { class: "hl-stat-value", children: [
            "$",
            formatNumber(market.price)
          ] }),
          /* @__PURE__ */ u$1("div", { class: "hl-stat-label", children: "Price" })
        ] }),
        /* @__PURE__ */ u$1("div", { class: "hl-stat hl-tooltip", "data-tooltip": TOOLTIPS.openInterest, children: [
          /* @__PURE__ */ u$1("div", { class: "hl-stat-value", children: [
            "$",
            formatNumber(market.openInterest * market.price)
          ] }),
          /* @__PURE__ */ u$1("div", { class: "hl-stat-label", children: "Open Interest" })
        ] }),
        /* @__PURE__ */ u$1("div", { class: "hl-stat hl-tooltip", "data-tooltip": TOOLTIPS.bookImbalance, children: [
          /* @__PURE__ */ u$1("div", { class: `hl-stat-value ${orderbook.imbalance > 0.15 ? "positive" : orderbook.imbalance < -0.15 ? "negative" : ""}`, children: [
            (orderbook.imbalance * 100).toFixed(0),
            "%"
          ] }),
          /* @__PURE__ */ u$1("div", { class: "hl-stat-label", children: "Book Imbalance" })
        ] }),
        /* @__PURE__ */ u$1("div", { class: "hl-stat hl-tooltip", "data-tooltip": TOOLTIPS.funding, children: [
          /* @__PURE__ */ u$1("div", { class: `hl-stat-value ${Math.abs(market.fundingAnnualized) > 0.5 ? "warning" : ""}`, children: formatPct(market.fundingAnnualized) }),
          /* @__PURE__ */ u$1("div", { class: "hl-stat-label", children: "Funding (Ann.)" })
        ] })
      ] }),
      settings.showInsight && insight && /* @__PURE__ */ u$1("div", { class: `hl-insight hl-insight--${insight.type}`, children: [
        /* @__PURE__ */ u$1("div", { class: "hl-insight-header", children: [
          /* @__PURE__ */ u$1("span", { class: "hl-insight-icon", children: [
            insight.type === "bullish" && "▲",
            insight.type === "bearish" && "▼",
            insight.type === "warning" && "⚠",
            insight.type === "info" && "ℹ"
          ] }),
          /* @__PURE__ */ u$1("span", { class: "hl-insight-title", children: insight.title })
        ] }),
        /* @__PURE__ */ u$1("div", { class: "hl-insight-message", children: insight.message })
      ] }),
      settings.showCVD && /* @__PURE__ */ u$1("div", { class: `hl-section ${collapsed.cvd ? "collapsed" : ""}`, children: [
        /* @__PURE__ */ u$1("div", { class: "hl-section-header", onClick: () => toggle("cvd"), children: [
          /* @__PURE__ */ u$1("span", { class: "hl-section-title", children: [
            "Order Flow (CVD)",
            /* @__PURE__ */ u$1(InfoIcon, { tooltip: TOOLTIPS.cvd })
          ] }),
          /* @__PURE__ */ u$1("span", { class: `hl-section-badge ${getCvdMomentumColor(cvd.momentum)}`, children: cvd.momentum.replace("_", " ").toUpperCase() })
        ] }),
        /* @__PURE__ */ u$1("div", { class: "hl-section-content", children: [
          cvd.divergence && /* @__PURE__ */ u$1("div", { class: `hl-alert ${cvd.divergence === "bullish" ? "bullish" : "bearish"}`, children: [
            cvd.divergence === "bullish" ? "Bullish" : "Bearish",
            " divergence detected"
          ] }),
          /* @__PURE__ */ u$1("div", { class: "hl-cvd-deltas", children: [
            /* @__PURE__ */ u$1("div", { class: "hl-cvd-delta", children: [
              /* @__PURE__ */ u$1("span", { class: "hl-cvd-label", children: "5m" }),
              /* @__PURE__ */ u$1("span", { class: `hl-cvd-value ${cvd.delta5m > 0 ? "positive" : cvd.delta5m < 0 ? "negative" : ""}`, children: [
                cvd.delta5m > 0 ? "+" : "",
                formatCompact(cvd.delta5m)
              ] })
            ] }),
            /* @__PURE__ */ u$1("div", { class: "hl-cvd-delta", children: [
              /* @__PURE__ */ u$1("span", { class: "hl-cvd-label", children: "15m" }),
              /* @__PURE__ */ u$1("span", { class: `hl-cvd-value ${cvd.delta15m > 0 ? "positive" : cvd.delta15m < 0 ? "negative" : ""}`, children: [
                cvd.delta15m > 0 ? "+" : "",
                formatCompact(cvd.delta15m)
              ] })
            ] }),
            /* @__PURE__ */ u$1("div", { class: "hl-cvd-delta", children: [
              /* @__PURE__ */ u$1("span", { class: "hl-cvd-label", children: "1h" }),
              /* @__PURE__ */ u$1("span", { class: `hl-cvd-value ${cvd.delta1h > 0 ? "positive" : cvd.delta1h < 0 ? "negative" : ""}`, children: [
                cvd.delta1h > 0 ? "+" : "",
                formatCompact(cvd.delta1h)
              ] })
            ] })
          ] }),
          /* @__PURE__ */ u$1("div", { class: "hl-cvd-bar", children: /* @__PURE__ */ u$1(
            "div",
            {
              class: "hl-cvd-bar-fill",
              style: `width: ${Math.min(Math.abs(cvd.delta5m) / (Math.abs(cvd.delta15m) || 1) * 50, 100)}%; background: ${cvd.delta5m > 0 ? "#0ECB81" : "#F6465D"}`
            }
          ) })
        ] })
      ] }),
      settings.showWhaleActivity && /* @__PURE__ */ u$1("div", { class: `hl-section ${collapsed.tape ? "collapsed" : ""}`, children: [
        /* @__PURE__ */ u$1("div", { class: "hl-section-header", onClick: () => toggle("tape"), children: [
          /* @__PURE__ */ u$1("span", { class: "hl-section-title", children: [
            "Whale Activity",
            /* @__PURE__ */ u$1(InfoIcon, { tooltip: TOOLTIPS.whaleActivity })
          ] }),
          /* @__PURE__ */ u$1("span", { class: `hl-section-badge ${tape.whaleCount5m > 3 ? "badge-warning" : "badge-neutral"}`, children: [
            tape.whaleCount5m,
            " whales (5m)"
          ] })
        ] }),
        /* @__PURE__ */ u$1("div", { class: "hl-section-content", children: [
          /* @__PURE__ */ u$1("div", { class: "hl-tape-intensity", children: [
            /* @__PURE__ */ u$1("div", { class: "hl-tape-bar", children: [
              /* @__PURE__ */ u$1("div", { class: "hl-tape-buy", style: `width: ${tape.buyIntensity}%` }),
              /* @__PURE__ */ u$1("div", { class: "hl-tape-sell", style: `width: ${tape.sellIntensity}%` })
            ] }),
            /* @__PURE__ */ u$1("div", { class: "hl-tape-labels", children: [
              /* @__PURE__ */ u$1("span", { class: "positive hl-tooltip hl-tooltip--left", "data-tooltip": TOOLTIPS.buyIntensity, children: [
                tape.buyIntensity,
                "% Buy"
              ] }),
              /* @__PURE__ */ u$1("span", { class: "negative hl-tooltip hl-tooltip--right", "data-tooltip": TOOLTIPS.sellIntensity, children: [
                tape.sellIntensity,
                "% Sell"
              ] })
            ] })
          ] }),
          /* @__PURE__ */ u$1("div", { class: "hl-row", children: [
            /* @__PURE__ */ u$1("span", { class: "hl-row-label", children: "Whale Buys" }),
            /* @__PURE__ */ u$1("span", { class: "hl-row-value positive", children: [
              "$",
              formatCompact(tape.whaleBuyVolume)
            ] })
          ] }),
          /* @__PURE__ */ u$1("div", { class: "hl-row", children: [
            /* @__PURE__ */ u$1("span", { class: "hl-row-label", children: "Whale Sells" }),
            /* @__PURE__ */ u$1("span", { class: "hl-row-value negative", children: [
              "$",
              formatCompact(tape.whaleSellVolume)
            ] })
          ] }),
          tape.lastWhale && /* @__PURE__ */ u$1("div", { class: "hl-last-whale", children: [
            /* @__PURE__ */ u$1("span", { class: tape.lastWhale.side === "buy" ? "positive" : "negative", children: [
              "Last: $",
              formatCompact(tape.lastWhale.notional),
              " ",
              tape.lastWhale.side.toUpperCase()
            ] }),
            /* @__PURE__ */ u$1("span", { class: "hl-whale-time", children: new Date(tape.lastWhale.timestamp).toLocaleTimeString() })
          ] })
        ] })
      ] }),
      settings.showOIDivergence && /* @__PURE__ */ u$1("div", { class: `hl-section ${collapsed.oiDiv ? "collapsed" : ""}`, children: [
        /* @__PURE__ */ u$1("div", { class: "hl-section-header", onClick: () => toggle("oiDiv"), children: [
          /* @__PURE__ */ u$1("span", { class: "hl-section-title", children: [
            "OI × Price",
            /* @__PURE__ */ u$1(InfoIcon, { tooltip: TOOLTIPS.oiDivergence })
          ] }),
          /* @__PURE__ */ u$1("span", { class: `hl-section-badge ${oiDivergence.pattern === "new_longs" ? "badge-positive" : oiDivergence.pattern === "new_shorts" || oiDivergence.pattern === "long_liquidation" ? "badge-negative" : "badge-neutral"}`, children: getOiPatternLabel(oiDivergence.pattern) })
        ] }),
        /* @__PURE__ */ u$1("div", { class: "hl-section-content", children: [
          /* @__PURE__ */ u$1("div", { class: "hl-divergence-meter", children: [
            /* @__PURE__ */ u$1("div", { class: "hl-divergence-track", children: [
              /* @__PURE__ */ u$1(
                "div",
                {
                  class: "hl-divergence-fill",
                  style: `width: ${Math.abs(oiDivergence.score)}%; margin-left: ${oiDivergence.score >= 0 ? "50%" : `${50 - Math.abs(oiDivergence.score)}%`}; background: ${oiDivergence.score >= 0 ? "#0ECB81" : "#F6465D"}`
                }
              ),
              /* @__PURE__ */ u$1("div", { class: "hl-divergence-center" })
            ] }),
            /* @__PURE__ */ u$1("div", { class: "hl-divergence-labels", children: [
              /* @__PURE__ */ u$1("span", { children: "Bearish" }),
              /* @__PURE__ */ u$1("span", { children: "Bullish" })
            ] })
          ] }),
          /* @__PURE__ */ u$1("div", { class: "hl-row", children: [
            /* @__PURE__ */ u$1("span", { class: "hl-row-label", children: "Price (1h)" }),
            /* @__PURE__ */ u$1("span", { class: `hl-row-value ${oiDivergence.priceChange > 0 ? "positive" : oiDivergence.priceChange < 0 ? "negative" : ""}`, children: [
              oiDivergence.priceChange > 0 ? "+" : "",
              oiDivergence.priceChange.toFixed(2),
              "%"
            ] })
          ] }),
          /* @__PURE__ */ u$1("div", { class: "hl-row", children: [
            /* @__PURE__ */ u$1("span", { class: "hl-row-label", children: "OI (1h)" }),
            /* @__PURE__ */ u$1("span", { class: `hl-row-value ${oiDivergence.oiChange > 0 ? "positive" : oiDivergence.oiChange < 0 ? "negative" : ""}`, children: [
              oiDivergence.oiChange > 0 ? "+" : "",
              oiDivergence.oiChange.toFixed(2),
              "%"
            ] })
          ] }),
          /* @__PURE__ */ u$1("div", { class: "hl-row", children: [
            /* @__PURE__ */ u$1("span", { class: "hl-row-label", children: "Strength" }),
            /* @__PURE__ */ u$1("span", { class: "hl-row-value", children: oiDivergence.strength.charAt(0).toUpperCase() + oiDivergence.strength.slice(1) })
          ] })
        ] })
      ] }),
      settings.showPressureMap && /* @__PURE__ */ u$1("div", { class: `hl-section ${collapsed.pressure ? "collapsed" : ""}`, children: [
        /* @__PURE__ */ u$1("div", { class: "hl-section-header", onClick: () => toggle("pressure"), children: /* @__PURE__ */ u$1("span", { class: "hl-section-title", children: [
          "Pressure Map ±5%",
          /* @__PURE__ */ u$1(InfoIcon, { tooltip: TOOLTIPS.pressureMap })
        ] }) }),
        /* @__PURE__ */ u$1("div", { class: "hl-section-content", children: [
          /* @__PURE__ */ u$1("div", { class: "hl-pressure-item", children: [
            /* @__PURE__ */ u$1("div", { class: "hl-pressure-left", children: [
              /* @__PURE__ */ u$1("span", { class: "hl-pressure-arrow up", children: "▲" }),
              /* @__PURE__ */ u$1("span", { class: "hl-pressure-price", children: [
                "$",
                formatNumber(market.price * 1.05, 0)
              ] })
            ] }),
            /* @__PURE__ */ u$1("span", { class: "hl-pressure-liq", children: [
              "~$",
              formatNumber(pressure.upside.liqEstimate),
              " liq"
            ] })
          ] }),
          /* @__PURE__ */ u$1("div", { class: "hl-pressure-item", children: [
            /* @__PURE__ */ u$1("div", { class: "hl-pressure-left", children: [
              /* @__PURE__ */ u$1("span", { class: "hl-pressure-arrow down", children: "▼" }),
              /* @__PURE__ */ u$1("span", { class: "hl-pressure-price", children: [
                "$",
                formatNumber(market.price * 0.95, 0)
              ] })
            ] }),
            /* @__PURE__ */ u$1("span", { class: "hl-pressure-liq", children: [
              "~$",
              formatNumber(pressure.downside.liqEstimate),
              " liq"
            ] })
          ] })
        ] })
      ] }),
      settings.showGravity && /* @__PURE__ */ u$1("div", { class: `hl-section ${collapsed.gravity ? "collapsed" : ""}`, children: [
        /* @__PURE__ */ u$1("div", { class: "hl-section-header", onClick: () => toggle("gravity"), children: [
          /* @__PURE__ */ u$1("span", { class: "hl-section-title", children: [
            "Liquidation Gravity",
            /* @__PURE__ */ u$1(InfoIcon, { tooltip: TOOLTIPS.liqGravity })
          ] }),
          /* @__PURE__ */ u$1("span", { class: `hl-section-badge ${gravity.score === "HIGH_ABOVE" ? "badge-positive" : gravity.score === "HIGH_BELOW" ? "badge-negative" : "badge-neutral"}`, children: gravity.score === "HIGH_ABOVE" ? "Above" : gravity.score === "HIGH_BELOW" ? "Below" : "Balanced" })
        ] }),
        /* @__PURE__ */ u$1("div", { class: "hl-section-content", children: /* @__PURE__ */ u$1("div", { class: "hl-gravity-bar", children: [
          /* @__PURE__ */ u$1("span", { class: "hl-gravity-label below", children: [
            (gravity.densityBelow * 100).toFixed(0),
            "%"
          ] }),
          /* @__PURE__ */ u$1("div", { class: "hl-gravity-track", children: [
            gravity.score === "HIGH_BELOW" && /* @__PURE__ */ u$1("div", { class: "hl-gravity-fill left", style: "width: 60%" }),
            gravity.score === "HIGH_ABOVE" && /* @__PURE__ */ u$1("div", { class: "hl-gravity-fill right", style: "width: 60%" })
          ] }),
          /* @__PURE__ */ u$1("span", { class: "hl-gravity-label above", children: [
            (gravity.densityAbove * 100).toFixed(0),
            "%"
          ] })
        ] }) })
      ] }),
      settings.showCompression && /* @__PURE__ */ u$1("div", { class: `hl-section ${collapsed.compression ? "collapsed" : ""}`, children: [
        /* @__PURE__ */ u$1("div", { class: "hl-section-header", onClick: () => toggle("compression"), children: [
          /* @__PURE__ */ u$1("span", { class: "hl-section-title", children: [
            "Compression",
            /* @__PURE__ */ u$1(InfoIcon, { tooltip: TOOLTIPS.compression })
          ] }),
          /* @__PURE__ */ u$1("span", { class: `hl-section-badge ${compression.isCompressed ? "badge-warning" : "badge-neutral"}`, children: [
            compression.score,
            "/4 signals"
          ] })
        ] }),
        /* @__PURE__ */ u$1("div", { class: "hl-section-content", children: [
          compression.isCompressed && /* @__PURE__ */ u$1("div", { class: "hl-alert warning", children: "Expansion probability elevated" }),
          /* @__PURE__ */ u$1("div", { class: "hl-signals", children: [
            /* @__PURE__ */ u$1("div", { class: `hl-signal ${compression.signals.rangeNarrowing ? "active" : ""}`, children: [
              /* @__PURE__ */ u$1("span", { class: "hl-signal-dot" }),
              /* @__PURE__ */ u$1("span", { class: "hl-tooltip", "data-tooltip": TOOLTIPS.rangeNarrowing, children: "Range Narrow" })
            ] }),
            /* @__PURE__ */ u$1("div", { class: `hl-signal ${compression.signals.oiRising ? "active" : ""}`, children: [
              /* @__PURE__ */ u$1("span", { class: "hl-signal-dot" }),
              /* @__PURE__ */ u$1("span", { class: "hl-tooltip", "data-tooltip": TOOLTIPS.oiRising, children: "OI Rising" })
            ] }),
            /* @__PURE__ */ u$1("div", { class: `hl-signal ${compression.signals.fundingExtreme ? "active" : ""}`, children: [
              /* @__PURE__ */ u$1("span", { class: "hl-signal-dot" }),
              /* @__PURE__ */ u$1("span", { class: "hl-tooltip", "data-tooltip": TOOLTIPS.fundingExtreme, children: "Funding Extreme" })
            ] }),
            /* @__PURE__ */ u$1("div", { class: `hl-signal ${compression.signals.volumeDeclining ? "active" : ""}`, children: [
              /* @__PURE__ */ u$1("span", { class: "hl-signal-dot" }),
              /* @__PURE__ */ u$1("span", { class: "hl-tooltip", "data-tooltip": TOOLTIPS.volumeDeclining, children: "Volume Declining" })
            ] })
          ] }),
          /* @__PURE__ */ u$1("div", { class: "hl-row", style: "margin-top: 8px", children: [
            /* @__PURE__ */ u$1("span", { class: "hl-row-label hl-tooltip hl-tooltip--left", "data-tooltip": TOOLTIPS.bbWidth, children: "BB Width Percentile" }),
            /* @__PURE__ */ u$1("span", { class: `hl-row-value ${volatility.bbWidthPercentile < 0.2 ? "warning" : ""}`, children: formatPct(volatility.bbWidthPercentile) })
          ] })
        ] })
      ] }),
      settings.showTrapRisk && /* @__PURE__ */ u$1("div", { class: `hl-section ${collapsed.trap ? "collapsed" : ""}`, children: [
        /* @__PURE__ */ u$1("div", { class: "hl-section-header", onClick: () => toggle("trap"), children: [
          /* @__PURE__ */ u$1("span", { class: "hl-section-title", children: [
            "Trap Risk",
            /* @__PURE__ */ u$1(InfoIcon, { tooltip: TOOLTIPS.trapRisk })
          ] }),
          /* @__PURE__ */ u$1("span", { class: `hl-section-badge ${trap.elevated ? "badge-warning" : "badge-neutral"}`, children: trap.elevated ? "Elevated" : "Normal" })
        ] }),
        /* @__PURE__ */ u$1("div", { class: "hl-section-content", children: [
          trap.elevated && /* @__PURE__ */ u$1("div", { class: "hl-alert warning", children: [
            trap.direction === "long" ? "Longs" : "Shorts",
            " crowded. Squeeze risk elevated."
          ] }),
          /* @__PURE__ */ u$1("div", { class: "hl-row", children: [
            /* @__PURE__ */ u$1("span", { class: "hl-row-label", children: "OI Change" }),
            /* @__PURE__ */ u$1("span", { class: `hl-row-value ${trap.oiDelta > 10 ? "warning" : ""}`, children: [
              trap.oiDelta > 0 ? "+" : "",
              trap.oiDelta.toFixed(1),
              "%"
            ] })
          ] }),
          /* @__PURE__ */ u$1("div", { class: "hl-row", children: [
            /* @__PURE__ */ u$1("span", { class: "hl-row-label", children: "Funding σ" }),
            /* @__PURE__ */ u$1("span", { class: `hl-row-value ${Math.abs(trap.fundingDeviation) > 2 ? "warning" : ""}`, children: [
              trap.fundingDeviation > 0 ? "+" : "",
              trap.fundingDeviation.toFixed(2)
            ] })
          ] }),
          /* @__PURE__ */ u$1("div", { class: "hl-row", children: [
            /* @__PURE__ */ u$1("span", { class: "hl-row-label", children: "Price Move" }),
            /* @__PURE__ */ u$1("span", { class: "hl-row-value", children: [
              trap.priceMovement > 0 ? "+" : "",
              trap.priceMovement.toFixed(2),
              "%"
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ u$1("div", { class: "hl-footer", children: [
        /* @__PURE__ */ u$1("div", { class: "hl-footer-time", children: [
          "Updated ",
          new Date(state.lastUpdate).toLocaleTimeString()
        ] }),
        /* @__PURE__ */ u$1("div", { class: "hl-footer-disclaimer", children: "Not financial advice. For informational purposes only. Trade at your own risk." })
      ] })
    ] });
  }
  G(_(SidePanel, {}), document.getElementById("app"));
})();
//# sourceMappingURL=index.js.map
